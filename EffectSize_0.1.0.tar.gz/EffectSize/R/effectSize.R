# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

  # hsb_data <- read.csv("MLMES_applied_HSB_data.csv", header=TRUE)
  # save(hsb_data, file = "hsb_data2.rda")
  # # hsb_data2 <- data("update_hsb_data.rda")
  #
# hsb_data$student <- c(1:7185) # add student unique IDs
#
#
# ## Prep data for analysis ----
#
# ### L1 predictors ----
# #### check data ----
# # hist(hsb_data$minority)  #binary
# # hist(hsb_data$female)    #binary
# # hist(hsb_data$ses)       #normal
# #### effect-code L1 dummy variables for ease of interpretation ----
# hsb_data$minority_eff = as.numeric(car::recode(hsb_data$minority, "1 = 1; 0 = -1"))
# hsb_data$female_eff = as.numeric(car::recode(hsb_data$female, "1 = 1; 0 = -1"))
# #### cluster-mean center L1 predictors ----
# hsb_data$minority_eff_CMC = as.numeric(misty::center(hsb_data$minority_eff,
#                                                      type="CWC", cluster = hsb_data$school))
# hsb_data$female_eff_CMC = as.numeric(misty::center(hsb_data$female_eff,
#                                                    type="CWC", cluster = hsb_data$school))
# hsb_data$ses_CMC = as.numeric(misty::center(hsb_data$ses,
#                                             type="CWC", cluster = hsb_data$school))
#
# ### L2 predictors ----
# #### create L2 predictors file for centering and examining distributions ----
# hsb_data_L2 <- aggregate(x = hsb_data[c("mathach","ses","size","sector","disclim","himinty")],
#                          by = hsb_data[c("school")], FUN = mean)
# names(hsb_data_L2)[names(hsb_data_L2) == "mathach"] <- "mathach_agg"
# names(hsb_data_L2)[names(hsb_data_L2) == "ses"] <- "ses_agg"
# #### check preditor data ----
# # hist(hsb_data_L2$ses_agg)     #normal
# # hist(hsb_data_L2$size)        #moderate right-skew
# # hist(hsb_data_L2$sector)      #binary
# # hist(hsb_data_L2$disclim)     #normal
# # hist(hsb_data_L2$himinty)     #binary
# shapiro.test(hsb_data_L2$size) #sig not normal
# #### transform size using sqrt (better) ----
# hsb_data_L2$sqrt_size <- sqrt(hsb_data_L2$size)
# # hist(hsb_data_L2$sqrt_size)
# shapiro.test(hsb_data_L2$sqrt_size)
# #### effect-code L2 dummy variables for results interpretation ----
# hsb_data_L2$sector_eff = as.numeric(car::recode(hsb_data_L2$sector, "1 = 1; 0 = -1"))
# hsb_data_L2$himinty_eff = as.numeric(car::recode(hsb_data_L2$himinty, "1 = 1; 0 = -1"))
# #### grand-mean center L2 continuous variables ----
# hsb_data_L2$ses_agg_GMC <- as.numeric(scale(hsb_data_L2$ses_agg, scale = FALSE)) #scale=TRUE would be Z-scores
# hsb_data_L2$sqrt_size_GMC <- as.numeric(scale(hsb_data_L2$sqrt_size, scale = FALSE)) #scale=TRUE would be Z-scores
# hsb_data_L2$disclim_GMC <- as.numeric(scale(hsb_data_L2$disclim, scale = FALSE)) #scale=TRUE would be Z-scores
#
# ### merge L2 data with L1 data ----
# hsb_data <- merge(hsb_data,hsb_data_L2)
#
#
# ## ** DESCRIPTIVES ** (can skip) ----
#
# ### L1 descriptives ----
# L1_Ms <- colMeans(hsb_data[c("mathach","minority","female","ses_CMC")], na.rm=TRUE)
# L1_Ms <- as.data.frame(L1_Ms)
# colnames(L1_Ms) <- c("M")
# L1_SDs <- hsb_data[c("mathach","minority","female","ses_CMC")] %>%
#   summarize_all(., sd, na.rm=TRUE)
# L1_SDs <- as.data.frame(t(L1_SDs))
# L1_SDs
# colnames(L1_SDs) <- c("SD")
# L1_corr <- Hmisc::rcorr(as.matrix(hsb_data[,c("mathach","minority_eff_CMC","female_eff_CMC","ses_CMC",
#                                               "ses_agg","sqrt_size","sector","disclim","himinty")],type="pearson"))
# L1_corr_r <- round(as.data.frame(L1_corr$r),2)
# L1_corr_p <- round(as.data.frame(L1_corr$P),3)
#
# variables <- as.data.frame(names(L1_corr_r))
# colnames(variables) <- c("Label")
#
# ### L2 descriptives ----
# L2_Ms <- colMeans(hsb_data_L2[c("ses_agg","sqrt_size","sector","disclim","himinty")], na.rm=TRUE)
# L2_Ms <- as.data.frame(L2_Ms)
# L2_Ms
# colnames(L2_Ms) <- c("M")
# L2_SDs <- hsb_data_L2[c("ses_agg_GMC","sqrt_size","sector","disclim","himinty")] %>%
#   summarize_all(., sd, na.rm=TRUE)
# L2_SDs <- as.data.frame(t(L2_SDs))
# L2_SDs
# colnames(L2_SDs) <- c("SD")
# L2_corr <- Hmisc::rcorr(as.matrix(hsb_data_L2[,c("mathach_agg","ses_agg","sqrt_size",
#                                                  "sector","disclim","himinty")],type="pearson"))
# L2_corr_r <- round(as.data.frame(L2_corr$r),2)
# L2_corr_p <- round(as.data.frame(L2_corr$P),3)
#
# ### combined descriptives ----
# #### means and SDs ----
# means <- rbind(L1_Ms,L2_Ms)
# SDs <- rbind(L1_SDs,L2_SDs)
# descriptives <- as.data.frame(cbind(variables,means,SDs))
# colnames(descriptives) <- c("Label","M","SD")
# descriptives$M <- round(as.numeric(descriptives$M),2)
# descriptives$SD <- round(as.numeric(descriptives$SD),2)
# rownames(descriptives) <- NULL
# descriptives
# #### zero-order correlations ----
# ##### insert L2 correlations where appropriate ----
# L1_corr_r
# rownames(L1_corr_r) <- NULL
# L2_corr_r
# rownames(L2_corr_r) <- NULL
# correlations <- L1_corr_r
# correlations$Label <- variables
# correlations <- correlations %>% relocate(Label, .before = mathach)
# L1_corr_r
# L2_corr_r
# correlations
# ##### with dependent variable ----
# ##### lower triangle
# correlations[5,2] <- L2_corr_r[2,1]
# correlations[6,2] <- L2_corr_r[3,1]
# correlations[7,2] <- L2_corr_r[4,1]
# correlations[8,2] <- L2_corr_r[5,1]
# correlations[9,2] <- L2_corr_r[6,1]
# ##### upper triangle
# correlations[1,6] <- L2_corr_r[2,1]
# correlations[1,7] <- L2_corr_r[3,1]
# correlations[1,8] <- L2_corr_r[4,1]
# correlations[1,9] <- L2_corr_r[5,1]
# correlations[1,10] <- L2_corr_r[6,1]
# ##### with each other ----
# ##### lower triangle
# correlations[6,6] <- L2_corr_r[3,2]
# correlations[7,6] <- L2_corr_r[4,2]
# correlations[8,6] <- L2_corr_r[5,2]
# correlations[9,6] <- L2_corr_r[6,2]
# correlations[7,7] <- L2_corr_r[4,3]
# correlations[8,7] <- L2_corr_r[5,3]
# correlations[9,7] <- L2_corr_r[6,3]
# correlations[8,8] <- L2_corr_r[5,4]
# correlations[9,8] <- L2_corr_r[6,4]
# correlations[9,9] <- L2_corr_r[6,5]
# ##### upper triangle
# correlations[5,7] <- L2_corr_r[3,2]
# correlations[5,8] <- L2_corr_r[4,2]
# correlations[5,9] <- L2_corr_r[5,2]
# correlations[5,10] <- L2_corr_r[6,2]
# correlations[6,8] <- L2_corr_r[4,3]
# correlations[6,9] <- L2_corr_r[5,3]
# correlations[6,10] <- L2_corr_r[6,3]
# correlations[7,9] <- L2_corr_r[5,4]
# correlations[7,10] <- L2_corr_r[6,4]
# correlations[8,10] <- L2_corr_r[6,5]
# colnames(correlations) <- c("Label",c(1:nrow(correlations)))
# #### final combined descriptives table ----
# correlations <- subset(correlations, select = -c(Label))
# descriptives$Number <- c(1:nrow(descriptives))
# descriptives$Variable <- car::recode(descriptives$Label, "
#                                          'mathach' = 'Math Achievement';
# 'minority_eff_CMC' = 'Student Minority Status';
# 'female_eff_CMC'   = 'Student Female Status';
# 'ses_CMC'   = 'Student SES (CMC)';
# 'ses_agg'   = 'School SES (Sample Aggregate)';
# 'sqrt_size' = 'School Size (Sqrt Transformed)';
# 'sector'    = 'School Private/Catholic Status';
# 'disclim'   = 'School Discipline Climate';
# 'himinty'   = 'School High % Minority Status'")
# descriptives <- descriptives %>% relocate(Number, .before = Label)
# descriptives <- descriptives %>% relocate(Variable, .after = Label)
# descriptive_data <- dplyr::bind_cols(descriptives,correlations)
#   save(hsb_data, file = "update_hsb_data.rda")
# data(update_hsb_data)
# hsb_m1a <- lmer(mathach ~
#                   minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
#                   ses_agg_GMC + # L2 aggregate predictor
#                   sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
#                   (1 | school), # random intercepts
#                 data = hsb_data, REML=FALSE)
# # hsb_m1b <- lmer(mathach ~
#                   minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
#                   ses_agg_GMC + # L2 aggregate predictor
#                   sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
#                   (1 + minority_eff_CMC | school), # random intercepts and slopes, cor
#                 data = hsb_data, REML=FALSE)
# hsb_m1c <- lmer(mathach ~
#                   minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
#                   ses_agg_GMC + # L2 aggregate predictor
#                   sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
#                   (1 + minority_eff_CMC + female_eff_CMC + ses_CMC | school), # random intercepts and slopes, cor
#                 data = hsb_data, REML=FALSE)
# EffectSize::initial()
# EffectSize::get_my_global()
# EffectSize::set_my_global(hsb_m1c)
# EffectSize::compute_fe_variance(hsb_m1c,hsb_data)
# EffectSize::compute_re_variance(hsb_m1c,hsb_data)
# EffectSize::format_var_comp()
# EffectSize::get_lme4_results(hsb_m1c)
# EffectSize::get_cv_results(hsb_m1c,hsb_data)
# EffectSize::format_final_results()
#### creat variables ----
  # model <- hsb_m1

  CoefES <- function(model)
  {
     data <- model@frame
    .effectSize$initial();
    .effectSize$set_my_global(model)
    .effectSize$compute_fe_variance(model,data)
    .effectSize$compute_re_variance(model,data)
    .effectSize$format_var_comp()
    .effectSize$get_lme4_results(model)
    .effectSize$get_cv_results(model,hsb_data)
    .effectSize$format_final_results()
  }
  VarComp<- function(model){
     data <- model@frame
    .effectSize$initial();
    .effectSize$set_my_global(model)
    .effectSize$compute_fe_variance(model,data)
    .effectSize$compute_re_variance(model,data)
    .effectSize$format_var_comp()
  }
  Rsq <- function(model){
    data <- model@frame
    .effectSize$initial();
    .effectSize$set_my_global(model);
    .effectSize$compute_fe_variance(model,data)
    .effectSize$compute_re_variance(model,data)
    .effectSize$format_var_comp()
    .effectSize$compute_R_square(model)
  }

  .effectSize <- new.env(parent = emptyenv())

  # store random effects counts
  .effectSize$RE_cluster_name <- NULL
  .effectSize$RE_int_count <- NULL
  .effectSize$RE_slp_count <- NULL
  .effectSize$num_ran_eff <-  NULL
  # store random slope predictor information as simple list
  .effectSize$RE_slp_names <- NULL
  # store random slope predictor as comma-separated quoted list
  .effectSize$RE_slp_names_list  <- NULL
  # store random slope predictor as matrix (can only use this if there are any random slopes)
  .effectSize$RE_slp_names_matrix <- NULL
  # store predictor names as simple list
  .effectSize$L1_names <- NULL
  .effectSize$L2_names <- NULL
  # store predictor names as comma-separated quoted
  .effectSize$L1_names_raw <- NULL
  .effectSize$L2_names_raw <- NULL
  .effectSize$L1_P_coef_list <- NULL
  .effectSize$L2_Q_coef_list <- NULL
  # store predictor names as matrix
  .effectSize$L1_P_coef_names <- NULL
  .effectSize$L2_Q_coef_names <- NULL
  .effectSize$L1_P_coef <- NULL
  .effectSize$L2_Q_coef <- NULL
  .effectSize$results <- NULL
  .effectSize$initial <- function(){
  .effectSize <- new.env(parent = emptyenv())

  # store random effects counts
  .effectSize$RE_cluster_name <- NULL
  .effectSize$RE_int_count <- NULL
  .effectSize$RE_slp_count <- NULL
  .effectSize$num_ran_eff <-  NULL
  # store random slope predictor information as simple list
  .effectSize$RE_slp_names <- NULL
  # store random slope predictor as comma-separated quoted list
  .effectSize$RE_slp_names_list  <- NULL
  # store random slope predictor as matrix (can only use this if there are any random slopes)
  .effectSize$RE_slp_names_matrix <- NULL
  # store predictor names as simple list
  .effectSize$L1_names <- NULL
  .effectSize$L2_names <- NULL
  # store predictor names as comma-separated quoted
  .effectSize$L1_names_raw <- NULL
  .effectSize$L2_names_raw <- NULL
  .effectSize$L1_P_coef_list <- NULL
  .effectSize$L2_Q_coef_list <- NULL
  # store predictor names as matrix
  .effectSize$L1_P_coef_names <- NULL
  .effectSize$L2_Q_coef_names <- NULL
  .effectSize$L1_P_coef <- NULL
  .effectSize$L2_Q_coef <- NULL
  .effectSize$results <- NULL
}

#### varcov of predictors ----
  .effectSize$L1_P_fixef_cov   <- NULL
  .effectSize$L2_Q_fixef_cov   <- NULL

  #### var components by level ----
  .effectSize$L1_P_fixef_var   <- NULL
  .effectSize$L2_Q_fixef_var   <- NULL
  ### compute RE variances ----
  .effectSize$Tau_matrix <- NULL
  .effectSize$L1_resid_var <- NULL
  # Product_Sigma_Tau <- Sigma_matrix%*%Tau_matrix
  .effectSize$L2_ranef_int_var <- NULL
  # L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:num_ran_eff,2:num_ran_eff]) #var + 2*covar, exclude intercept var
  .effectSize$L1_ranef_slp_var <- NULL #no random slope effects
  .effectSize$L1_var  <- NULL
  .effectSize$L2_var  <- NULL
  .effectSize$tot_var <- NULL
  .effectSize$tot_sd  <- NULL
  .effectSize$L1_sd   <- NULL
  .effectSize$L2_sd   <- NULL
  .effectSize$var_decomp_table <- NULL

  #### set global variables ----
  .effectSize$set_my_global <- function(model) {
    .effectSize$RE_cluster_name <- .effectSize$get_random_effects(model)$cluster_names
    .effectSize$RE_int_count <-.effectSize$get_random_effects(model)$rand_int_count
    .effectSize$RE_slp_count <- .effectSize$get_random_effects(model)$rand_slp_count
    .effectSize$num_ran_eff <-  .effectSize$RE_int_count + .effectSize$RE_slp_count
    .effectSize$RE_slp_names <- as.character(.effectSize$get_random_effects(model)$rand_slp_names)
    .effectSize$RE_slp_names_list <- as.character(.effectSize$get_random_effects(model)$rand_slp_names)
    .effectSize$RE_slp_names_matrix <- as.matrix(.effectSize$get_random_effects(model)$rand_slp_names)
    colnames(.effectSize$RE_slp_names_matrix) <- c("Predictor")
    .effectSize$L1_names <- as.character(.effectSize$get_L1L2_predictors(model)$L1)
    .effectSize$L2_names <- as.character(.effectSize$get_L1L2_predictors(model)$L2)
    .effectSize$L1_names_raw <- .effectSize$get_L1L2_predictors(model)$L1
    .effectSize$L2_names_raw <- .effectSize$get_L1L2_predictors(model)$L2
    .effectSize$L1_P_coef_list <- as.character(.effectSize$L1_names_raw)
    .effectSize$L2_Q_coef_list <- as.character(.effectSize$L2_names_raw)
    # store predictor names as matrix
    .effectSize$L1_P_coef_names <- as.matrix(.effectSize$get_L1L2_predictors(model)$L1)
    colnames(.effectSize$L1_P_coef_names) <- c("Predictor")
    .effectSize$L2_Q_coef_names <- as.matrix(.effectSize$get_L1L2_predictors(model)$L2)
    colnames(.effectSize$L2_Q_coef_names) <- c("Predictor")

  }
  .effectSize$get_my_global <- function() {
    print(.effectSize$L2_ranef_int_var)
    print(.effectSize$L1_ranef_slp_var)
    print(.effectSize$var_decomp_table)
    print(.effectSize$results)
  }

  # library(tibble)
  # library(r2mlm) #decompose r2mlm: dig into the model longitudinal model, bar graph. variance components
  # library(dplyr)
  # library(Hmisc)
  # library(lmerTest)

  # var_decomp_table(hsb_m1, l1name, l2name)
  # R_square_abtain_test(hsb_m1)
  # R_square_abtain(hsb_m1)
  # create_result_dataframe(hsb_m1,l1name, l2name)
  # compute_adj_d(create_result_dataframe(hsb_m1,l1name, l2name),l1name,l2name,hsb_m1 )
  ### get number of random effects ----
  .effectSize$get_random_effects <- function(model) {
    vc_list <- VarCorr(model)

    # Extract clean cluster names (remove suffixes like ".1", ".2")
    cluster_names <- gsub("\\.\\d+$", "", names(vc_list))
    split_list <- split(vc_list, cluster_names)

    total_intercept <- 0
    total_slopes <- 0
    slope_names <- c()
    cluster_var_names <- unique(cluster_names)

    for (cluster_mats in split_list) {
      all_rows <- unlist(lapply(cluster_mats, rownames))

      # Remove cluster prefix if present
      prefix <- names(cluster_mats)[1]
      all_rows <- sub(paste0("^", prefix, "\\."), "", all_rows)

      # Count intercepts
      has_intercept <- any(all_rows == "(Intercept)")
      total_intercept <- total_intercept + as.integer(has_intercept)

      # Extract slopes
      slopes <- all_rows[all_rows != "(Intercept)"]
      total_slopes <- total_slopes + length(slopes)

      # Store slope names
      slope_names <- c(slope_names, slopes)
    }

    # Remove duplicate slope names
    slope_names <- unique(slope_names)

    # Return named list
    list(
      cluster_names   = cluster_var_names,
      rand_int_count = total_intercept,
      rand_slp_count = total_slopes,
      rand_slp_names = slope_names
    )
  }

  ### get names of predictors for each level ----
  .effectSize$get_L1L2_predictors <- function(model, cluster_var) {
    # extract the data actually used in the model
    mf <- model.frame(model)

    # get clustering variable name
    cluster_var <- names(model@flist)

    # get predictor names (exclude response and cluster_var itself)
    predictors <- setdiff(names(mf), c(all.vars(formula(model)[[2]]), cluster_var))

    # for each predictor, check if it varies within clusters
    results <- sapply(predictors, function(p) {
      by_vals <- tapply(mf[[p]], mf[[cluster_var]], function(x) length(unique(x)))
      if (all(by_vals == 1)) {
        return("L2")   # constant within each cluster
      } else {
        return("L1")   # varies within at least one cluster
      }
    })

    # return lists of names
    list(
      L2 = names(results[results == "L2"]),
      L1 = names(results[results == "L1"])
    )
  }

  .effectSize$compute_fe_variance <-function(model, data){
    all_coef_names <- as.data.frame(names(fixef(model)))
    all_coef_vals <- as.numeric(summary(model)$coef[,1])
    all_coef      <- cbind(all_coef_names,all_coef_vals)
    colnames(all_coef) <- c("Predictor","Coeff")
    all_coef$Predictor <- as.character(all_coef$Predictor)
    L1_P_coef <- as.data.frame(all_coef[all_coef$Predictor %in% .effectSize$L1_names, ])
    L2_Q_coef <- as.data.frame(all_coef[all_coef$Predictor %in% .effectSize$L2_names, ])
    L1_P_coef$Predictor <- NULL
    L2_Q_coef$Predictor <- NULL
    .effectSize$L1_P_coef <- as.matrix(L1_P_coef)
    .effectSize$L2_Q_coef <- as.matrix(L2_Q_coef)
    #### varcov of predictors ----
    L1_P_fixef_cov <- cov(data[.effectSize$L1_P_coef_list])
    L2_Q_fixef_cov <- cov(data[.effectSize$L2_Q_coef_list])
    .effectSize$L1_P_fixef_cov   <- as.matrix(L1_P_fixef_cov)
    .effectSize$L2_Q_fixef_cov   <- as.matrix(L2_Q_fixef_cov)

    #### var components by level ----
    .effectSize$L1_P_fixef_var   <- t(.effectSize$L1_P_coef)%*%.effectSize$L1_P_fixef_cov%*%.effectSize$L1_P_coef
    .effectSize$L2_Q_fixef_var   <- t(.effectSize$L2_Q_coef)%*%.effectSize$L2_Q_fixef_cov%*%.effectSize$L2_Q_coef

  }

  .effectSize$compute_re_variance <- function(model,data){

    if(.effectSize$RE_slp_count == 0)
    {
      .effectSize$Tau_matrix <- as.matrix(Matrix::bdiag(VarCorr(model)))
      .effectSize$L1_resid_var <- as.data.frame(VarCorr(model))[which(as.data.frame(VarCorr(model))$grp == 'Residual'),'vcov']
      # Product_Sigma_Tau <- Sigma_matrix%*%Tau_matrix
      .effectSize$L2_ranef_int_var <- as.numeric(.effectSize$Tau_matrix[1,1]) # intercept variance
      # L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:num_ran_eff,2:num_ran_eff]) #var + 2*covar, exclude intercept var
      .effectSize$L1_ranef_slp_var <- 0 #no random slope effects
    }else{
      #### when Pr = 0 random slopes then no Z matrix needed
      Z_matrix <- data[.effectSize$RE_slp_names_list]
      Z_matrix$Intercept <- c(rep(1,nrow(Z_matrix)))
      Z_matrix <- Z_matrix %>% relocate(Intercept, .before = everything())
      Sigma_matrix <- as.matrix(cov(Z_matrix))
      .effectSize$Tau_matrix <- as.matrix(Matrix::bdiag(VarCorr(model)))
      Product_Sigma_Tau <- Sigma_matrix%*%.effectSize$Tau_matrix
      .effectSize$L2_ranef_int_var <- as.numeric(.effectSize$Tau_matrix[1,1]) # intercept variance
      .effectSize$L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:.effectSize$num_ran_eff,2:.effectSize$num_ran_eff]) #var + 2*covar, exclude intercept var
      # L1_ranef_slp_var <- 0 #no random slope effects
      .effectSize$L1_resid_var <- as.data.frame(VarCorr(model))[which(as.data.frame(VarCorr(model))$grp == 'Residual'),'vcov']
    }
  }

  .effectSize$format_var_comp <-function(){
    .effectSize$L1_var  = as.numeric(.effectSize$L1_P_fixef_var + .effectSize$L1_ranef_slp_var + .effectSize$L1_resid_var)
    .effectSize$L2_var  = as.numeric(.effectSize$L2_Q_fixef_var + .effectSize$L2_ranef_int_var)
    .effectSize$tot_var = as.numeric(.effectSize$L1_var + .effectSize$L2_var)
    .effectSize$tot_sd  = as.numeric(sqrt(.effectSize$tot_var))
    .effectSize$L1_sd   = as.numeric(sqrt(.effectSize$L1_var))
    .effectSize$L2_sd   = as.numeric(sqrt(.effectSize$L2_var))
    var_decomp_table <- as.data.frame(rbind(
      c(.effectSize$L1_P_fixef_var,   .effectSize$L1_resid_var,  .effectSize$L1_ranef_slp_var, NA,               .effectSize$L1_var,  .effectSize$L1_sd),
      c(.effectSize$L2_Q_fixef_var,   NA,            NA,               .effectSize$L2_ranef_int_var, .effectSize$L2_var,  .effectSize$L2_sd),
      c((.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var), .effectSize$L1_resid_var, .effectSize$L1_ranef_slp_var, .effectSize$L2_ranef_int_var, .effectSize$tot_var, .effectSize$tot_sd)
    ))
    row_labels <- c("L1 Coeff","L2 Coeff", "All Coeff")
    colnames(var_decomp_table) <- c("PredictorVar","L1Var","L1SlpVar","L2Var","TotVar","SD")
    var_decomp_table <- cbind(row_labels,var_decomp_table)
    .effectSize$var_decomp_table <- var_decomp_table
    invisible(var_decomp_table)
  }

  .effectSize$compute_R_square <- function(){
    ### ** compute R^2 ----
    L1_Rsq_Fixed_Lev <- as.numeric(.effectSize$L1_P_fixef_var/.effectSize$L1_var)
    L1_Rsq_Fixed_Tot <- as.numeric(.effectSize$L1_P_fixef_var/.effectSize$tot_var)
    L2_Rsq_Fixed_Lev <- as.numeric(.effectSize$L2_Q_fixef_var/.effectSize$L2_var)
    L2_Rsq_Fixed_Tot <- as.numeric(.effectSize$L2_Q_fixef_var/.effectSize$tot_var)
    BothLev_Rsq_Fixed_Tot <- as.numeric((.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var)/.effectSize$tot_var)

  }

  .effectSize$get_lme4_results <- function(model){
    # summary of model results
    summ    <- summary(model)
    # assign coef level
    coef     <- names(fixef(model))
    coef_lev <- ifelse(coef == "(Intercept)", 2,        # always treat intercept as L2
                       ifelse(coef %in% .effectSize$L1_names, 1,
                              ifelse(coef %in% .effectSize$L2_names, 2, NA)))
    coef_info <- as.data.frame(cbind(coef,coef_lev))
    coef_info$coef <- as.character(coef_info$coef)
    coef_info$coef_lev <- as.numeric(coef_info$coef_lev)
    coef_info$rand_slp <- ifelse(coef_info$coef %in% .effectSize$RE_slp_names, 1, 0)
    coef_info$rand_slp <- as.numeric(coef_info$rand_slp)

    #### get lme4 results ----
    b       <- as.numeric(summ$coef[,1])
    se      <- as.numeric(summ$coef[,2])
    t       <- as.numeric(summ$coef[,4])
    df_Sat  <- as.numeric(summ$coef[,3]) # Satterthwaite df is default for lme4
    p_Sat   <- as.numeric(round(summ$coef[,5], 6)) # p-value based on t with lme4 df

    lme4_results <- as.data.frame(cbind(b,se,t,df_Sat,p_Sat))

    results <- cbind(coef_info,lme4_results)

    # compute BW df ----
    N = model@devcomp$dims[["N"]]
    J = as.numeric(ngrps(model, .effectSize$RE_cluster_name))
    M = as.numeric(c(N/J))
    ICC = as.numeric(c(.effectSize$L2_ranef_int_var/.effectSize$tot_var))
    Pr = as.numeric(.effectSize$RE_slp_count)
    Pf1 = nrow(.effectSize$L1_P_coef_names)
    Q   = nrow(.effectSize$L2_Q_coef_names)
    df_bw_L1     = as.numeric(c(N - J - Pf1             )) # only in no-random slope models
    df_bw_L2     = as.numeric(c(    J -            Q - 1))
    df_bw_tot    = as.numeric(c(N - J - Pf1 - Pr - Q - 1))
    #### assign BW df ----
    results$df_BW <- ifelse(
      results$rand_slp == 1,                 # L1 slopes with random slope
      ifelse(results$coef_lev == 1, df_bw_L2, df_bw_L2),  # L1 → L2 df, L2 → L2 df
      ifelse(results$coef_lev == 1, df_bw_L1, df_bw_L2)   # L1 slopes without random slope → L1 df, L2 → L2 df
    )
    #### assign p-values to t based on BW df ----
    results$p_BW <- round(as.numeric(2 * (1 - pt(abs(results$t), df = results$df_BW))),6)

    colnames(results) <- c("Predictor","level","rs","b","SE","t","df_Sat","p_Sat","df_BW","p_BW")
    #### level-specific ----
    results$adj_d_lev <- ifelse(
      results$level == 1,
      results$b / .effectSize$L1_sd,
      results$b / .effectSize$L2_sd)

    #### total ----
    results$adj_d_tot <- results$b/ .effectSize$tot_sd
    .effectSize$results <- results
  }
  ###### function conditional_variances() ----
  .effectSize$conditional_variances <- function(data, predictors) {
    cond_vars <- setNames(numeric(length(predictors)), predictors)

    for (pred in predictors) {
      others <- setdiff(predictors, pred)
      if (length(others) == 0) {
        cond_vars[pred] <- var(data[[pred]], na.rm = TRUE)
      } else {
        fit <- lm(data[[pred]] ~ ., data = data[others])
        cond_vars[pred] <- var(resid(fit), na.rm = TRUE)
      }
    }
    cond_vars
  }

  ##### function wrapper relying on getL1L2predictors() ----
  .effectSize$get_conditional_variances <- function(model, data) {
    clust_var <- names(model@flist)[1]
    preds <- .effectSize$get_L1L2_predictors(model, clust_var)
    out <- list()

    # L1 conditional variances
    if (length(preds$L1) > 0) {
      out$L1 <- .effectSize$conditional_variances(data, preds$L1)
    }

    # L2 conditional variances (aggregate to cluster means first)
    if (length(preds$L2) > 0) {
      level2_data <- data %>%
        group_by(.data[[clust_var]]) %>%
        summarise(across(all_of(preds$L2), \(x) mean(x, na.rm = TRUE)), .groups = "drop")
      out$L2 <- .effectSize$conditional_variances(level2_data, preds$L2)
    }
    out
  }

  #### get conditional variances to results
  .effectSize$get_cv_results <- function(model, data){
    ##### get_conditional_variances(model, data)
    cond_variance <- .effectSize$get_conditional_variances(model, data)
    cond_variance$L1
    cond_variance$L2

    ##### add conditional variances to 'results' ----
    .effectSize$results$cond_variance <- NA_real_ #initialize
    for (i in seq_len(nrow(.effectSize$results))) {
      pred <- .effectSize$results$Predictor[i]
      lev  <- .effectSize$results$level[i]

      if (pred == "(Intercept)") {
        # Intercept always treated as L2
        .effectSize$results$cond_variance[i] <- NA_real_  # or set to a fixed value if you prefer
      } else if (lev == 1 && pred %in% names(cond_variance$L1)) {
        .effectSize$results$cond_variance[i] <- cond_variance$L1[pred]
      } else if (lev == 2 && pred %in% names(cond_variance$L2)) {
        .effectSize$results$cond_variance[i] <- cond_variance$L2[pred]
      }
    }

    #### level-specific ----
    .effectSize$results$sr2_lev <- ifelse(
      .effectSize$results$level == 1,
      (.effectSize$results$b^2) * .effectSize$results$cond_variance / .effectSize$L1_var,
      (.effectSize$results$b^2) * .effectSize$results$cond_variance / .effectSize$L2_var
    )

    #### total ----
    .effectSize$results$sr2_tot <- (.effectSize$results$b^2)*.effectSize$results$cond_variance / .effectSize$tot_var

    ### remove unneeded results ----
    .effectSize$results$cond_variance <- NULL
  }

  #### format the result
  .effectSize$format_final_results <- function()
  {
    format_results           <- .effectSize$results
    format_results$b         <- round(format_results$b,2)
    format_results$SE        <- round(format_results$SE,2)
    format_results$t         <- round(format_results$t,2)
    format_results$df_Sat    <- round(format_results$df_Sat,2)
    format_results$p_Sat     <- round(format_results$p_Sat,4)
    format_results$df_BW     <- round(format_results$df_BW,0)
    format_results$p_BW      <- round(format_results$p_BW,4)
    format_results$adj_d_lev <- round(format_results$adj_d_lev,4)
    format_results$adj_d_tot <- round(format_results$adj_d_tot,4)
    format_results$sr2_lev   <- round(format_results$sr2_lev,4)
    format_results$sr2_tot   <- round(format_results$sr2_tot,4)
    format_results$Variable <- format_results$Predictor
    format_results <- format_results %>% relocate(Variable, .before = everything())
    format_results$Predictor <- NULL
    format_results$level <- NULL
    format_results$rs <- NULL
    names(format_results)[names(format_results) == "b"] <- "Coeff"
    row.names(format_results) <- NULL
    invisible(format_results) # print
  }
  .effectSize$compute_R_square <- function(model){
    L1_Rsq_Fixed_Lev <- as.numeric(.effectSize$L1_P_fixef_var/.effectSize$L1_var)
    L1_Rsq_Fixed_Tot <- as.numeric(.effectSize$L1_P_fixef_var/.effectSize$tot_var)
    L2_Rsq_Fixed_Lev <- as.numeric(.effectSize$L2_Q_fixef_var/.effectSize$L2_var)
    L2_Rsq_Fixed_Tot <- as.numeric(.effectSize$L2_Q_fixef_var/.effectSize$tot_var)
    RE_Rsq_RS_Lev <- as.numeric(.effectSize$L1_ranef_slp_var/.effectSize$L1_var)
    RE_Rsq_RS_Tot <- as.numeric(.effectSize$L1_ranef_slp_var/.effectSize$tot_var)
    RE_Rsq_RI_Lev <- as.numeric(.effectSize$L2_ranef_int_var/.effectSize$L2_var)
    RE_Rsq_RI_Tot <- as.numeric(.effectSize$L2_ranef_int_var/.effectSize$tot_var)

    Rsq_FE_Tot <- as.numeric((.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var)/
                               (.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var+.effectSize$L1_ranef_slp_var+
                                  .effectSize$L1_resid_var + .effectSize$L2_ranef_int_var))

    Rsq_FERS_Lev <- as.numeric((.effectSize$L1_P_fixef_var+.effectSize$L1_ranef_slp_var)/
                                 (.effectSize$L1_P_fixef_var+.effectSize$L1_ranef_slp_var+
                                    .effectSize$L1_resid_var ))

    Rsq_FERS_Tot <- as.numeric((.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var+.effectSize$L1_ranef_slp_var)/
                                 (.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var+.effectSize$L1_ranef_slp_var+
                                    .effectSize$L1_resid_var + .effectSize$L2_ranef_int_var))

    Rsq_All_Tot <- as.numeric((.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var+.effectSize$L1_ranef_slp_var+.effectSize$L2_ranef_int_var)/
                                (.effectSize$L1_P_fixef_var+.effectSize$L2_Q_fixef_var+.effectSize$L1_ranef_slp_var+
                                   .effectSize$L1_resid_var + .effectSize$L2_ranef_int_var))

    Rsq_FE_L1   <- c("FE_L1",          L1_Rsq_Fixed_Tot, L1_Rsq_Fixed_Lev, NA              )
    Rsq_FE_L2   <- c("FE_L2",          L2_Rsq_Fixed_Tot, NA,               L2_Rsq_Fixed_Lev)
    Rsq_RE_RS   <- c("RS_L1",          RE_Rsq_RS_Tot,    RE_Rsq_RS_Lev,    NA              )
    Rsq_RE_RI   <- c("RI_L2",          RE_Rsq_RI_Tot,    NA,               RE_Rsq_RI_Lev   )
    Rsq_FE_tot1 <- c("FE_total",       Rsq_FE_Tot,       NA,               NA              )
    Rsq_FE_tot2 <- c("FE_RS_total",    Rsq_FERS_Tot,     Rsq_FERS_Lev,     NA              )
    Rsq_FE_tot3 <- c("FE_RS_RI_total", Rsq_All_Tot,      NA,               NA              )

    R2_vals_table <- as.data.frame(rbind(Rsq_FE_L1,Rsq_FE_L2,
                                         Rsq_RE_RS,Rsq_RE_RI,
                                         Rsq_FE_tot1,Rsq_FE_tot2,Rsq_FE_tot3))

    colnames(R2_vals_table)<- c("Effect","TotalRsq","L1Rsq","L2Rsq")
    R2_vals_table$TotalRsq <- round(as.numeric(R2_vals_table$TotalRsq),6)
    R2_vals_table$L1Rsq    <- round(as.numeric(R2_vals_table$L1Rsq),6)
    R2_vals_table$L2Rsq    <- round(as.numeric(R2_vals_table$L2Rsq),6)
    rownames(R2_vals_table) <- NULL

    #### print R^2 results ----
    R2_vals_table

    #### as check: view same R^2 using r2mlm package ----
    r2mlm_Rsq <- r2mlm(model, bargraph = FALSE)$R2s

    R2_vals_table <- R2_vals_table %>%
      mutate(across(where(is.numeric), ~ round(.x, 6)))

    invisible(R2_vals_table) # print
  }
