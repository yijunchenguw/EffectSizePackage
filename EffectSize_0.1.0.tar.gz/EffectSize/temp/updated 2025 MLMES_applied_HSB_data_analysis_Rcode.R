# MLMES Coeff ESs applied example code for HS&B dataset using lme4 ----
# Note:  Code written using R version 4.5.1
# Note:  Use Control+Shift+O to see outline view of analyses and calcs


## Call libraries ----
library(dplyr)     ### manipulating data
library(Hmisc)     ### obtaining descriptives as shown in paper
library(Matrix)    ### required for lme4
library(lme4)      ### multilevel modeling package
library(lmerTest)  ### lme4 Satterthwaite fixed effects df and t-tests
library(r2mlm)     ### R^2 vals for 2L models (can be substituted with var comps)


## Clean environment ----
rm(list=ls())
gc()


## Remove scientific notation ----
options(scipen=999)


## Set working directory to folder where datafile is downloaded ----

## Import data ----
hsb_data <- read.csv("MLMES_applied_HSB_data.csv", header=TRUE)
# str(hsb_data) # check data variables
# 'data.frame':	7185 obs. of  11 variables:
# $ school  : int  1224 1224 1224 1224 1224 1224 1224 1224 1224 1224 ...
# $ student : int  1 2 3 4 5 6 7 8 9 10 ...
# $ minority: int  0 0 0 0 0 0 0 0 0 0 ...
# $ female  : int  1 1 0 0 0 0 1 0 1 0 ...
# $ ses     : num  -1.528 -0.588 -0.528 -0.668 -0.158 ...
# $ mathach : num  5.88 19.71 20.35 8.78 17.9 ...
# $ size    : int  842 842 842 842 842 842 842 842 842 842 ...
# $ sector  : int  0 0 0 0 0 0 0 0 0 0 ...
# $ disclim : num  1.6 1.6 1.6 1.6 1.6 ...
# $ himinty : int  0 0 0 0 0 0 0 0 0 0 ...

# L1 student variables are minority, female, ses, mathach
#       minority, indicator for student ethnicity (1 = minority, 0 = otherwise)
#       female, indicator for student female status (1 = female, 0 = otherwise)
#       ses, standardized scale of student's parent edu/occupation/income
#       mathach, measure of math achievement based on scale from:
#                Heyns, B., & Hilton, T. L. (1982).
#                The cognitive tests for High School and Beyond: An assessment.
#                Sociology of Education, 55, 89-102.
# L2 school variables are size, sector, pracad, disclim, himinty
#       size (school enrollment)
#       sector (1 = Catholic, 0 = public)
#       disclim (a scale measuring disciplinary climate)
#       himnty (1 = more than 40% minority enrollment, 0 = less than 40%

sum(is.na(hsb_data)) # check for missingness
# [1] 0 # no missing

dplyr::n_distinct(hsb_data$school) # check number of schools
# [1] 160

hsb_data$student <- c(1:7185) # add student unique IDs


## Prep data for analysis ----

### L1 predictors ----
#### check data ----
# hist(hsb_data$minority)  #binary
# hist(hsb_data$female)    #binary
# hist(hsb_data$ses)       #normal
#### effect-code L1 dummy variables for ease of interpretation ----
hsb_data$minority_eff = as.numeric(car::recode(hsb_data$minority, "1 = 1; 0 = -1"))
hsb_data$female_eff = as.numeric(car::recode(hsb_data$female, "1 = 1; 0 = -1"))
#### cluster-mean center L1 predictors ----
hsb_data$minority_eff_CMC = as.numeric(misty::center(hsb_data$minority_eff,
                                                     type="CWC", cluster = hsb_data$school))
hsb_data$female_eff_CMC = as.numeric(misty::center(hsb_data$female_eff,
                                                   type="CWC", cluster = hsb_data$school))
hsb_data$ses_CMC = as.numeric(misty::center(hsb_data$ses,
                                            type="CWC", cluster = hsb_data$school))

### L2 predictors ----
#### create L2 predictors file for centering and examining distributions ----
hsb_data_L2 <- aggregate(x = hsb_data[c("mathach","ses","size","sector","disclim","himinty")],
                         by = hsb_data[c("school")], FUN = mean)
names(hsb_data_L2)[names(hsb_data_L2) == "mathach"] <- "mathach_agg"
names(hsb_data_L2)[names(hsb_data_L2) == "ses"] <- "ses_agg"
#### check preditor data ----
# hist(hsb_data_L2$ses_agg)     #normal
# hist(hsb_data_L2$size)        #moderate right-skew
# hist(hsb_data_L2$sector)      #binary
# hist(hsb_data_L2$disclim)     #normal
# hist(hsb_data_L2$himinty)     #binary
shapiro.test(hsb_data_L2$size) #sig not normal
#### transform size using sqrt (better) ----
hsb_data_L2$sqrt_size <- sqrt(hsb_data_L2$size)
# hist(hsb_data_L2$sqrt_size)
shapiro.test(hsb_data_L2$sqrt_size)
#### effect-code L2 dummy variables for results interpretation ----
hsb_data_L2$sector_eff = as.numeric(car::recode(hsb_data_L2$sector, "1 = 1; 0 = -1"))
hsb_data_L2$himinty_eff = as.numeric(car::recode(hsb_data_L2$himinty, "1 = 1; 0 = -1"))
#### grand-mean center L2 continuous variables ----
hsb_data_L2$ses_agg_GMC <- as.numeric(scale(hsb_data_L2$ses_agg, scale = FALSE)) #scale=TRUE would be Z-scores
hsb_data_L2$sqrt_size_GMC <- as.numeric(scale(hsb_data_L2$sqrt_size, scale = FALSE)) #scale=TRUE would be Z-scores
hsb_data_L2$disclim_GMC <- as.numeric(scale(hsb_data_L2$disclim, scale = FALSE)) #scale=TRUE would be Z-scores

### merge L2 data with L1 data ----
hsb_data <- merge(hsb_data,hsb_data_L2)


## ** DESCRIPTIVES ** (can skip) ----

### L1 descriptives ----
L1_Ms <- colMeans(hsb_data[c("mathach","minority","female","ses_CMC")], na.rm=TRUE)
L1_Ms <- as.data.frame(L1_Ms)
colnames(L1_Ms) <- c("M")
L1_SDs <- hsb_data[c("mathach","minority","female","ses_CMC")] %>%
  summarize_all(., sd, na.rm=TRUE)
L1_SDs <- as.data.frame(t(L1_SDs))
L1_SDs
colnames(L1_SDs) <- c("SD")
L1_corr <- Hmisc::rcorr(as.matrix(hsb_data[,c("mathach","minority_eff_CMC","female_eff_CMC","ses_CMC",
                                              "ses_agg","sqrt_size","sector","disclim","himinty")],type="pearson"))
L1_corr_r <- round(as.data.frame(L1_corr$r),2)
L1_corr_p <- round(as.data.frame(L1_corr$P),3)

variables <- as.data.frame(names(L1_corr_r))
colnames(variables) <- c("Label")

### L2 descriptives ----
L2_Ms <- colMeans(hsb_data_L2[c("ses_agg","sqrt_size","sector","disclim","himinty")], na.rm=TRUE)
L2_Ms <- as.data.frame(L2_Ms)
L2_Ms
colnames(L2_Ms) <- c("M")
L2_SDs <- hsb_data_L2[c("ses_agg_GMC","sqrt_size","sector","disclim","himinty")] %>%
  summarize_all(., sd, na.rm=TRUE)
L2_SDs <- as.data.frame(t(L2_SDs))
L2_SDs
colnames(L2_SDs) <- c("SD")
L2_corr <- Hmisc::rcorr(as.matrix(hsb_data_L2[,c("mathach_agg","ses_agg","sqrt_size",
                                              "sector","disclim","himinty")],type="pearson"))
L2_corr_r <- round(as.data.frame(L2_corr$r),2)
L2_corr_p <- round(as.data.frame(L2_corr$P),3)

### combined descriptives ----
#### means and SDs ----
means <- rbind(L1_Ms,L2_Ms)
SDs <- rbind(L1_SDs,L2_SDs)
descriptives <- as.data.frame(cbind(variables,means,SDs))
colnames(descriptives) <- c("Label","M","SD")
descriptives$M <- round(as.numeric(descriptives$M),2)
descriptives$SD <- round(as.numeric(descriptives$SD),2)
rownames(descriptives) <- NULL
descriptives
#### zero-order correlations ----
##### insert L2 correlations where appropriate ----
L1_corr_r
rownames(L1_corr_r) <- NULL
L2_corr_r
rownames(L2_corr_r) <- NULL
correlations <- L1_corr_r
correlations$Label <- variables
correlations <- correlations %>% relocate(Label, .before = mathach)
L1_corr_r
L2_corr_r
correlations
##### with dependent variable ----
##### lower triangle
correlations[5,2] <- L2_corr_r[2,1]
correlations[6,2] <- L2_corr_r[3,1]
correlations[7,2] <- L2_corr_r[4,1]
correlations[8,2] <- L2_corr_r[5,1]
correlations[9,2] <- L2_corr_r[6,1]
##### upper triangle
correlations[1,6] <- L2_corr_r[2,1]
correlations[1,7] <- L2_corr_r[3,1]
correlations[1,8] <- L2_corr_r[4,1]
correlations[1,9] <- L2_corr_r[5,1]
correlations[1,10] <- L2_corr_r[6,1]
##### with each other ----
##### lower triangle
correlations[6,6] <- L2_corr_r[3,2]
correlations[7,6] <- L2_corr_r[4,2]
correlations[8,6] <- L2_corr_r[5,2]
correlations[9,6] <- L2_corr_r[6,2]
correlations[7,7] <- L2_corr_r[4,3]
correlations[8,7] <- L2_corr_r[5,3]
correlations[9,7] <- L2_corr_r[6,3]
correlations[8,8] <- L2_corr_r[5,4]
correlations[9,8] <- L2_corr_r[6,4]
correlations[9,9] <- L2_corr_r[6,5]
##### upper triangle
correlations[5,7] <- L2_corr_r[3,2]
correlations[5,8] <- L2_corr_r[4,2]
correlations[5,9] <- L2_corr_r[5,2]
correlations[5,10] <- L2_corr_r[6,2]
correlations[6,8] <- L2_corr_r[4,3]
correlations[6,9] <- L2_corr_r[5,3]
correlations[6,10] <- L2_corr_r[6,3]
correlations[7,9] <- L2_corr_r[5,4]
correlations[7,10] <- L2_corr_r[6,4]
correlations[8,10] <- L2_corr_r[6,5]
colnames(correlations) <- c("Label",c(1:nrow(correlations)))
#### final combined descriptives table ----
correlations <- subset(correlations, select = -c(Label))
descriptives$Number <- c(1:nrow(descriptives))
descriptives$Variable <- car::recode(descriptives$Label, "
                                         'mathach' = 'Math Achievement';
'minority_eff_CMC' = 'Student Minority Status';
'female_eff_CMC'   = 'Student Female Status';
'ses_CMC'   = 'Student SES (CMC)';
'ses_agg'   = 'School SES (Sample Aggregate)';
'sqrt_size' = 'School Size (Sqrt Transformed)';
'sector'    = 'School Private/Catholic Status';
'disclim'   = 'School Discipline Climate';
'himinty'   = 'School High % Minority Status'")
descriptives <- descriptives %>% relocate(Number, .before = Label)
descriptives <- descriptives %>% relocate(Variable, .after = Label)
descriptive_data <- dplyr::bind_cols(descriptives,correlations)

### save descriptives to working directory ----
write.csv(descriptive_data,"MLMES_applied_HSB_descriptives.csv",row.names=FALSE)


## ** MODELS ** ----

### m0 random intercept empty model ----
hsb_m0 <- lmer(mathach ~ 1 +
                   (1|school),
                 data = hsb_data, REML=FALSE)
summary(hsb_m0)
variances_m0 = as.data.frame(VarCorr(hsb_m0))
cluster_var_m0 = variances_m0[1,'vcov']
resid_var_m0 = variances_m0[2,'vcov']
#### ICC of math acheive (Y) ----
ICC_m0 <- cluster_var_m0/(cluster_var_m0 + resid_var_m0)
cluster_var_m0
resid_var_m0
ICC_m0

### m1a random intercept, full model ----
hsb_m1a <- lmer(mathach ~
                 minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
                 ses_agg_GMC + # L2 aggregate predictor
                 sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
                 (1 | school), # random intercepts
               data = hsb_data, REML=FALSE)

### m1b random intercept and 1 random L1 slope, full model ----
hsb_m1b <- lmer(mathach ~
                  minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
                  ses_agg_GMC + # L2 aggregate predictor
                  sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
                  (1 + minority_eff_CMC | school), # random intercepts and slopes, cor
                data = hsb_data, REML=FALSE)

### m1c random intercept and 3 random L1 slopes, full model ----
hsb_m1c <- lmer(mathach ~
                  minority_eff_CMC + female_eff_CMC + ses_CMC + #L1 predictors
                  ses_agg_GMC + # L2 aggregate predictor
                  sqrt_size_GMC + sector_eff + disclim_GMC + himinty_eff +  # L2 true predictors
                  (1 + minority_eff_CMC + female_eff_CMC + ses_CMC | school), # random intercepts and slopes, cor
                data = hsb_data, REML=FALSE)

#### model comparisons ----
anova(hsb_m1a,hsb_m1b, test="Chisq") # model 1b fits better than model 1a
anova(hsb_m1b,hsb_m1c, test="Chisq") # model 1c fits better than model 1b
anova(hsb_m1a,hsb_m1c, test="Chisq") # model 1c fits better than model 1a

#### model results ----
summary(hsb_m1a) # best fitting BIC
summary(hsb_m1b)
summary(hsb_m1c) # best fitting AIC, LRT



# ** EFFECT SIZES ** ----


## 1) ** m1a random intercept + fixed L1 slopes model ----

### ! user specified ----
model <- hsb_m1a    ##### !! user specified
data  <- hsb_data   ##### !! user specified

### get number of random effects ----
get_random_effects <- function(model) {
  vc_list <- VarCorr(model)

  # Extract clean cluster names (remove suffixes like ".1", ".2")
  cluster_names <- gsub("\\.\\d+$", "", names(vc_list))
  split_list <- split(vc_list, cluster_names)

  total_intercept <- 0
  total_slopes <- 0
  slope_names <- c()
  cluster_var_names <- unique(cluster_names)

  for (cluster_mats in split_list) {
    all_rows <- unlist(lapply(cluster_mats, rownames))

    # Remove cluster prefix if present
    prefix <- names(cluster_mats)[1]
    all_rows <- sub(paste0("^", prefix, "\\."), "", all_rows)

    # Count intercepts
    has_intercept <- any(all_rows == "(Intercept)")
    total_intercept <- total_intercept + as.integer(has_intercept)

    # Extract slopes
    slopes <- all_rows[all_rows != "(Intercept)"]
    total_slopes <- total_slopes + length(slopes)

    # Store slope names
    slope_names <- c(slope_names, slopes)
  }

  # Remove duplicate slope names
  slope_names <- unique(slope_names)

  # Return named list
  list(
    cluster_names   = cluster_var_names,
    rand_int_count = total_intercept,
    rand_slp_count = total_slopes,
    rand_slp_names = slope_names
  )
}

# store cluster variable name
RE_cluster_name <- get_random_effects(model)$cluster_names
RE_cluster_name

# store random effects counts
RE_int_count <- get_random_effects(model)$rand_int_count
RE_slp_count <- get_random_effects(model)$rand_slp_count
num_ran_eff =  RE_int_count + RE_slp_count
RE_int_count
RE_slp_count
num_ran_eff

# store random slope predictor information as simple list
RE_slp_names <- get_random_effects(model)$rand_slp_names
RE_slp_names <- as.character(RE_slp_names)
RE_slp_names

# store random slope predictor as comma-separated quoted list
RE_slp_names_raw <- get_random_effects(model)$rand_slp_names
RE_slp_names_list <- as.character(RE_slp_names_raw)
RE_slp_names_list

# store random slope predictor as matrix (can only use this if there are any random slopes)
RE_slp_names_matrix <- as.matrix(get_random_effects(model)$rand_slp_names)
colnames(RE_slp_names_matrix) <- c("Predictor")


### get names of predictors for each level ----
get_L1L2_predictors <- function(model, cluster_var) {
  # extract the data actually used in the model
  mf <- model.frame(model)

  # get clustering variable name
  cluster_var <- names(model@flist)

  # get predictor names (exclude response and cluster_var itself)
  predictors <- setdiff(names(mf), c(all.vars(formula(model)[[2]]), cluster_var))

  # for each predictor, check if it varies within clusters
  results <- sapply(predictors, function(p) {
    by_vals <- tapply(mf[[p]], mf[[cluster_var]], function(x) length(unique(x)))
    if (all(by_vals == 1)) {
      return("L2")   # constant within each cluster
    } else {
      return("L1")   # varies within at least one cluster
    }
  })

  # return lists of names
  list(
    L2 = names(results[results == "L2"]),
    L1 = names(results[results == "L1"])
  )
}

# store predictor names as simple list
L1_names <- get_L1L2_predictors(model)$L1
L2_names <- get_L1L2_predictors(model)$L2
L1_names <- as.character(L1_names)
L2_names <- as.character(L2_names)

# store predictor names as comma-separated quoted
L1_names_raw <- get_L1L2_predictors(model)$L1
L2_names_raw <- get_L1L2_predictors(model)$L2
L1_P_coef_list <- as.character(L1_names_raw)
L2_Q_coef_list <- as.character(L2_names_raw)

# store predictor names as matrix
L1_P_coef_names <- as.matrix(get_L1L2_predictors(model)$L1)
colnames(L1_P_coef_names) <- c("Predictor")
L2_Q_coef_names <- as.matrix(get_L1L2_predictors(model)$L2)
colnames(L2_Q_coef_names) <- c("Predictor")

### compute FE variance ----

#### model coef values ----
all_coef_names <- as.data.frame(names(fixef(model)))
all_coef_vals <- as.numeric(summary(model)$coef[,1])
all_coef      <- cbind(all_coef_names,all_coef_vals)
colnames(all_coef) <- c("Predictor","Coeff")
all_coef$Predictor <- as.character(all_coef$Predictor)
L1_P_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L1_names, ])
L2_Q_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L2_names, ])
L1_P_coef$Predictor <- NULL
L2_Q_coef$Predictor <- NULL
L1_P_coef <- as.matrix(L1_P_coef)
L2_Q_coef <- as.matrix(L2_Q_coef)

#### varcov of predictors ----
L1_P_fixef_cov <- cov(data[L1_P_coef_list])
L2_Q_fixef_cov <- cov(data[L2_Q_coef_list])
L1_P_fixef_cov   <- as.matrix(L1_P_fixef_cov)
L2_Q_fixef_cov   <- as.matrix(L2_Q_fixef_cov)

#### var components by level ----
L1_P_fixef_var   <- t(L1_P_coef)%*%L1_P_fixef_cov%*%L1_P_coef
L2_Q_fixef_var   <- t(L2_Q_coef)%*%L2_Q_fixef_cov%*%L2_Q_coef

### compute RE variances ----
# ! Yijun: need help here in automating code so that if Pr = 0 then assign L1_ranef_slpvar to 0
# ! in m1b and m1c there is no issue because Pr > 0
# ! lines 436 - 439 and 441 and 443 and 446 are turned off, and line 444 is turned on
# ! for comparison with other 2 models, search term: compute RE variances

#### create Z design matrix for random slope effects ----
#### when Pr = 0 random slopes then no Z matrix needed
# Z_matrix <- data[RE_slp_names_list]
# Z_matrix$Intercept <- c(rep(1,nrow(Z_matrix)))
# Z_matrix <- Z_matrix <- Z_matrix %>% relocate(Intercept, .before = everything())
# Sigma_matrix <- as.matrix(cov(Z_matrix))
Tau_matrix <- as.matrix(Matrix::bdiag(VarCorr(model)))
# Product_Sigma_Tau <- Sigma_matrix%*%Tau_matrix
L2_ranef_int_var <- as.numeric(Tau_matrix[1,1]) # intercept variance
# L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:num_ran_eff,2:num_ran_eff]) #var + 2*covar, exclude intercept var
L1_ranef_slp_var <- 0 #no random slope effects
L1_resid_var <- as.data.frame(VarCorr(model))[which(as.data.frame(VarCorr(model))$grp == 'Residual'),'vcov']
# Sigma_matrix
Tau_matrix
L2_ranef_int_var
L1_ranef_slp_var

#### optional: format, print, save var comp results ----
L1_var  = as.numeric(L1_P_fixef_var + L1_ranef_slp_var + L1_resid_var)
L2_var  = as.numeric(L2_Q_fixef_var + L2_ranef_int_var)
tot_var = as.numeric(L1_var + L2_var)
tot_sd  = as.numeric(sqrt(tot_var))
L1_sd   = as.numeric(sqrt(L1_var))
L2_sd   = as.numeric(sqrt(L2_var))
var_decomp_table <- as.data.frame(rbind(
  c(L1_P_fixef_var,   L1_resid_var,  L1_ranef_slp_var, NA,               L1_var,  L1_sd),
  c(L2_Q_fixef_var,   NA,            NA,               L2_ranef_int_var, L2_var,  L2_sd),
  c((L1_P_fixef_var+L2_Q_fixef_var), L1_resid_var, L1_ranef_slp_var, L2_ranef_int_var, tot_var, tot_sd)
))
row_labels <- c("L1 Coeff","L2 Coeff", "All Coeff")
colnames(var_decomp_table) <- c("PredictorVar","L1Var","L1SlpVar","L2Var","TotVar","SD")
var_decomp_table <- cbind(row_labels,var_decomp_table)

var_decomp_table # print

write.csv(var_decomp_table,"MLMES_applied_HSB_mod_varcomp_results_m1a.csv",row.names = FALSE)

### ** compute R^2 ----
L1_Rsq_Fixed_Lev <- as.numeric(L1_P_fixef_var/L1_var)
L1_Rsq_Fixed_Tot <- as.numeric(L1_P_fixef_var/tot_var)
L2_Rsq_Fixed_Lev <- as.numeric(L2_Q_fixef_var/L2_var)
L2_Rsq_Fixed_Tot <- as.numeric(L2_Q_fixef_var/tot_var)
BothLev_Rsq_Fixed_Tot <- as.numeric((L1_P_fixef_var+L2_Q_fixef_var)/tot_var)
# L1_Rsq_Fixed_Lev
# L2_Rsq_Fixed_Lev
# L1_Rsq_Fixed_Tot
# L2_Rsq_Fixed_Tot
# BothLev_Rsq_Fixed_Tot

#### as check: compute same R^2 using r2mlm package ----
r2mlm(model, bargraph = FALSE)$R2s
R2_list <- r2mlm(model, bargraph = FALSE)$R2s
R2_tot <- R2_list[,1]
R2_w   <- R2_list[,2]
R2_b   <- R2_list[,3]
R2_vals <- as.data.frame(rbind(R2_w,R2_b,R2_tot))
R2_vals$type <- c("w","b","tot")
row.names(R2_vals) <- NULL
R2_vals <- R2_vals %>% relocate(type, .before = f1)
# R2_vals
L1_lev_R2w <- as.numeric(R2_vals[1,2])
L2_lev_R2b <- as.numeric(R2_vals[2,3])
L1_tot_R2w <- as.numeric(R2_vals[3,2])
L2_tot_R2b <- as.numeric(R2_vals[3,3])
tot_R2tot  <- as.numeric(R2_vals[3,6])
# L1_lev_R2w
# L2_lev_R2b
# L1_tot_R2w
# L2_tot_R2b
# tot_R2tot

#### optional: format, print, save R-square results from r2mlm table ----
R2_vals_table <- as.data.frame(t(R2_vals))
R2_vals_table <- R2_vals_table[-c(1), ]
colnames(R2_vals_table) <- c("L1_within","L2_between","Total")
R2_vals_table$L1_within <- round(as.numeric(R2_vals_table$L1_within),4)
R2_vals_table$L2_between <- round(as.numeric(R2_vals_table$L2_between),4)
R2_vals_table$Total <- round(as.numeric(R2_vals_table$Total),4)
R2_vals_table$Type <- c("Fixed_L1","Fixed_L2","Rand_slp","Rand_int","Fixed_all","Fixed_all_Rand_slp","All")
R2_vals_table <- R2_vals_table %>% relocate(Type, .before = L1_within)
row.names(R2_vals_table) <- NULL

R2_vals_table # print

write.csv(R2_vals_table,"MLMES_applied_HSB_mod_r2mlm_R2_ESresults_m1a.csv",row.names = FALSE)

### ** create model results dataframe ----

#### summary of model results ----
summ    <- summary(model)

#### assign coef level based on get_L1L2_predictors() function ----
coef     <- names(fixef(model))
coef_lev <- ifelse(coef == "(Intercept)", 2,        # always treat intercept as L2
                     ifelse(coef %in% L1_names, 1,
                            ifelse(coef %in% L2_names, 2, NA)))
coef_info <- as.data.frame(cbind(coef,coef_lev))
coef_info$coef <- as.character(coef_info$coef)
coef_info$coef_lev <- as.numeric(coef_info$coef_lev)
coef_info$rand_slp <- ifelse(coef_info$coef %in% RE_slp_names, 1, 0)
coef_info$rand_slp <- as.numeric(coef_info$rand_slp)

#### get lme4 results ----
b       <- as.numeric(summ$coef[,1])
se      <- as.numeric(summ$coef[,2])
t       <- as.numeric(summ$coef[,4])
df_Sat  <- as.numeric(summ$coef[,3]) # Satterthwaite df is default for lme4
p_Sat   <- as.numeric(round(summ$coef[,5], 6)) # p-value based on t with lme4 df

lme4_results <- as.data.frame(cbind(b,se,t,df_Sat,p_Sat))

results <- cbind(coef_info,lme4_results)

#### compute BW df ----
N = model@devcomp$dims[["N"]]
J = as.numeric(ngrps(model, RE_cluster_name))
M = as.numeric(c(N/J))
ICC = as.numeric(c(L2_ranef_int_var/tot_var))
Pr = as.numeric(RE_slp_count)
Pf1 = nrow(L1_P_coef_names)
Q   = nrow(L2_Q_coef_names)
df_bw_L1     = as.numeric(c(N - J - Pf1             )) # only in no-random slope models
df_bw_L2     = as.numeric(c(    J -            Q - 1))
df_bw_tot    = as.numeric(c(N - J - Pf1 - Pr - Q - 1))
J
Pf1
Pr
Q
df_bw_L1
df_bw_L2
df_bw_tot

#### assign BW df ----
results$df_BW <- ifelse(
  results$rand_slp == 1,                 # L1 slopes with random slope
  ifelse(results$coef_lev == 1, df_bw_L2, df_bw_L2),  # L1 → L2 df, L2 → L2 df
  ifelse(results$coef_lev == 1, df_bw_L1, df_bw_L2)   # L1 slopes without random slope → L1 df, L2 → L2 df
)
#### assign p-values to t based on BW df ----
results$p_BW <- round(as.numeric(2 * (1 - pt(abs(results$t), df = results$df_BW))),6)

colnames(results) <- c("Predictor","level","rs","b","SE","t","df_Sat","p_Sat","df_BW","p_BW")
results

### ** compute adj_d ----

#### level-specific ----
results$adj_d_lev <- ifelse(
  results$level == 1,
  results$b / L1_sd,
  results$b / L2_sd)

#### total ----
results$adj_d_tot <- results$b/ tot_sd
results


### ** compute sr^2 ----

#### get conditional predictor variances ----
###### function conditional_variances() ----
conditional_variances <- function(data, predictors) {
  cond_vars <- setNames(numeric(length(predictors)), predictors)

  for (pred in predictors) {
    others <- setdiff(predictors, pred)
    if (length(others) == 0) {
      cond_vars[pred] <- var(data[[pred]], na.rm = TRUE)
    } else {
      fit <- lm(data[[pred]] ~ ., data = data[others])
      cond_vars[pred] <- var(resid(fit), na.rm = TRUE)
    }
  }
  cond_vars
}

##### function wrapper relying on getL1L2predictors() ----
get_conditional_variances <- function(model, data) {
  clust_var <- names(model@flist)[1]
  preds <- get_L1L2_predictors(model, clust_var)
  out <- list()

  # L1 conditional variances
  if (length(preds$L1) > 0) {
    out$L1 <- conditional_variances(data, preds$L1)
  }

  # L2 conditional variances (aggregate to cluster means first)
  if (length(preds$L2) > 0) {
    level2_data <- data %>%
      group_by(.data[[clust_var]]) %>%
      summarise(across(all_of(preds$L2), \(x) mean(x, na.rm = TRUE)), .groups = "drop")
    out$L2 <- conditional_variances(level2_data, preds$L2)
  }

  out
}

##### apply function to model and data ----
##### get_conditional_variances(model, data)
cond_variance <- get_conditional_variances(model, data)
cond_variance$L1
cond_variance$L2

##### add conditional variances to 'results' ----
results$cond_variance <- NA_real_ #initialize
for (i in seq_len(nrow(results))) {
  pred <- results$Predictor[i]
  lev  <- results$level[i]

  if (pred == "(Intercept)") {
    # Intercept always treated as L2
    results$cond_variance[i] <- NA_real_  # or set to a fixed value if you prefer
  } else if (lev == 1 && pred %in% names(cond_variance$L1)) {
    results$cond_variance[i] <- cond_variance$L1[pred]
  } else if (lev == 2 && pred %in% names(cond_variance$L2)) {
    results$cond_variance[i] <- cond_variance$L2[pred]
  }
}

#### level-specific ----
results$sr2_lev <- ifelse(
  results$level == 1,
  (results$b^2) * results$cond_variance / L1_var,
  (results$b^2) * results$cond_variance / L2_var
)

#### total ----
results$sr2_tot <- (results$b^2)*results$cond_variance / tot_var

### remove unneeded results ----
results$cond_variance <- NULL

### print results ----
results

### optional: formatting and saving results ----
format_results           <- results
format_results$b         <- round(format_results$b,2)
format_results$SE        <- round(format_results$SE,2)
format_results$t         <- round(format_results$t,2)
format_results$df_Sat    <- round(format_results$df_Sat,2)
format_results$p_Sat     <- round(format_results$p_Sat,4)
format_results$df_BW     <- round(format_results$df_BW,0)
format_results$p_BW      <- round(format_results$p_BW,4)
format_results$adj_d_lev <- round(format_results$adj_d_lev,4)
format_results$adj_d_tot <- round(format_results$adj_d_tot,4)
format_results$sr2_lev   <- round(format_results$sr2_lev,4)
format_results$sr2_tot   <- round(format_results$sr2_tot,4)

format_results$Variable <- car::recode(format_results$Predictor, "
                                         '(Intercept)' = 'Intercept';
'minority_eff_CMC' = 'Student Minority Status (Effect-coded)';
'female_eff_CMC'   = 'Student Female Status (Effect-coded)';
'ses_CMC'   = 'Student SES (CMC)';
'ses_agg_GMC'   = 'School SES (Sample Aggregate, GMC)';
'sqrt_size_GMC' = 'School Size (Sqrt Transformed, GMC)';
'sector_eff'    = 'School Private/Catholic Status (Effect-coded)';
'disclim_GMC'   = 'School Discipline Climate (GMC)';
'himinty_eff'   = 'School High % Minority Status (Effect-coded)'")
format_results <- format_results %>% relocate(Variable, .before = everything())
format_results$Predictor <- NULL
format_results$level <- NULL
format_results$rs <- NULL
names(format_results)[names(format_results) == "b"] <- "Coeff"
row.names(format_results) <- NULL

format_results # print

write.csv(format_results,"MLMES_applied_HSB_mod_coef_ESresults_m1a.csv",row.names=FALSE) #save


## 2) ** m1b random int + 1 random L1 slope ----
### !! user specified ----
model <- hsb_m1b    ##### !! user specified
data  <- hsb_data   ##### !! user specified

### get number of random effects ----
get_random_effects <- function(model) {
  vc_list <- VarCorr(model)

  # Extract clean cluster names (remove suffixes like ".1", ".2")
  cluster_names <- gsub("\\.\\d+$", "", names(vc_list))
  split_list <- split(vc_list, cluster_names)

  total_intercept <- 0
  total_slopes <- 0
  slope_names <- c()
  cluster_var_names <- unique(cluster_names)

  for (cluster_mats in split_list) {
    all_rows <- unlist(lapply(cluster_mats, rownames))

    # Remove cluster prefix if present
    prefix <- names(cluster_mats)[1]
    all_rows <- sub(paste0("^", prefix, "\\."), "", all_rows)

    # Count intercepts
    has_intercept <- any(all_rows == "(Intercept)")
    total_intercept <- total_intercept + as.integer(has_intercept)

    # Extract slopes
    slopes <- all_rows[all_rows != "(Intercept)"]
    total_slopes <- total_slopes + length(slopes)

    # Store slope names
    slope_names <- c(slope_names, slopes)
  }

  # Remove duplicate slope names
  slope_names <- unique(slope_names)

  # Return named list
  list(
    cluster_names   = cluster_var_names,
    rand_int_count = total_intercept,
    rand_slp_count = total_slopes,
    rand_slp_names = slope_names
  )
}

# store cluster variable name
RE_cluster_name <- get_random_effects(model)$cluster_names
RE_cluster_name

# store random effects counts
RE_int_count <- get_random_effects(model)$rand_int_count
RE_slp_count <- get_random_effects(model)$rand_slp_count
num_ran_eff =  RE_int_count + RE_slp_count
RE_int_count
RE_slp_count
num_ran_eff

# store random slope predictor information as simple list
RE_slp_names <- get_random_effects(model)$rand_slp_names
RE_slp_names <- as.character(RE_slp_names)
RE_slp_names

# store random slope predictor as comma-separated quoted list
RE_slp_names_raw <- get_random_effects(model)$rand_slp_names
RE_slp_names_list <- as.character(RE_slp_names_raw)
RE_slp_names_list

# store random slope predictor as matrix (can only use this if there are any random slopes)
RE_slp_names_matrix <- as.matrix(get_random_effects(model)$rand_slp_names)
colnames(RE_slp_names_matrix) <- c("Predictor")


### get names of predictors for each level ----
get_L1L2_predictors <- function(model, cluster_var) {
  # extract the data actually used in the model
  mf <- model.frame(model)

  # get clustering variable name
  cluster_var <- names(model@flist)

  # get predictor names (exclude response and cluster_var itself)
  predictors <- setdiff(names(mf), c(all.vars(formula(model)[[2]]), cluster_var))

  # for each predictor, check if it varies within clusters
  results <- sapply(predictors, function(p) {
    by_vals <- tapply(mf[[p]], mf[[cluster_var]], function(x) length(unique(x)))
    if (all(by_vals == 1)) {
      return("L2")   # constant within each cluster
    } else {
      return("L1")   # varies within at least one cluster
    }
  })

  # return lists of names
  list(
    L2 = names(results[results == "L2"]),
    L1 = names(results[results == "L1"])
  )
}

# store predictor names as simple list
L1_names <- get_L1L2_predictors(model)$L1
L2_names <- get_L1L2_predictors(model)$L2
L1_names <- as.character(L1_names)
L2_names <- as.character(L2_names)

# store predictor names as comma-separated quoted
L1_names_raw <- get_L1L2_predictors(model)$L1
L2_names_raw <- get_L1L2_predictors(model)$L2
L1_P_coef_list <- as.character(L1_names_raw)
L2_Q_coef_list <- as.character(L2_names_raw)

# store predictor names as matrix
L1_P_coef_names <- as.matrix(get_L1L2_predictors(model)$L1)
colnames(L1_P_coef_names) <- c("Predictor")
L2_Q_coef_names <- as.matrix(get_L1L2_predictors(model)$L2)
colnames(L2_Q_coef_names) <- c("Predictor")

### compute FE variance ----

#### model coef values ----
all_coef_names <- as.data.frame(names(fixef(model)))
all_coef_vals <- as.numeric(summary(model)$coef[,1])
all_coef      <- cbind(all_coef_names,all_coef_vals)
colnames(all_coef) <- c("Predictor","Coeff")
all_coef$Predictor <- as.character(all_coef$Predictor)
L1_P_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L1_names, ])
L2_Q_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L2_names, ])
L1_P_coef$Predictor <- NULL
L2_Q_coef$Predictor <- NULL
L1_P_coef <- as.matrix(L1_P_coef)
L2_Q_coef <- as.matrix(L2_Q_coef)

#### varcov of predictors ----
L1_P_fixef_cov <- cov(data[L1_P_coef_list])
L2_Q_fixef_cov <- cov(data[L2_Q_coef_list])
L1_P_fixef_cov   <- as.matrix(L1_P_fixef_cov)
L2_Q_fixef_cov   <- as.matrix(L2_Q_fixef_cov)

#### var components by level ----
L1_P_fixef_var   <- t(L1_P_coef)%*%L1_P_fixef_cov%*%L1_P_coef
L2_Q_fixef_var   <- t(L2_Q_coef)%*%L2_Q_fixef_cov%*%L2_Q_coef

### compute RE variances ----

#### create Z design matrix for random slope effects ----
#### when Pr = 0 random slopes then no Z matrix needed
Z_matrix <- data[RE_slp_names_list]
Z_matrix$Intercept <- c(rep(1,nrow(Z_matrix)))
Z_matrix <- Z_matrix <- Z_matrix %>% relocate(Intercept, .before = everything())
Sigma_matrix <- as.matrix(cov(Z_matrix))
Tau_matrix <- as.matrix(Matrix::bdiag(VarCorr(model)))
Product_Sigma_Tau <- Sigma_matrix%*%Tau_matrix
L2_ranef_int_var <- as.numeric(Tau_matrix[1,1]) # intercept variance
L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:num_ran_eff,2:num_ran_eff]) #var + 2*covar, exclude intercept var
# L1_ranef_slp_var <- 0 #no random slope effects
L1_resid_var <- as.data.frame(VarCorr(model))[which(as.data.frame(VarCorr(model))$grp == 'Residual'),'vcov']
Sigma_matrix
Tau_matrix
L2_ranef_int_var
L1_ranef_slp_var

#### optional: format, print, save var comp results ----
L1_var  = as.numeric(L1_P_fixef_var + L1_ranef_slp_var + L1_resid_var)
L2_var  = as.numeric(L2_Q_fixef_var + L2_ranef_int_var)
tot_var = as.numeric(L1_var + L2_var)
tot_sd  = as.numeric(sqrt(tot_var))
L1_sd   = as.numeric(sqrt(L1_var))
L2_sd   = as.numeric(sqrt(L2_var))
var_decomp_table <- as.data.frame(rbind(
  c(L1_P_fixef_var,   L1_resid_var,  L1_ranef_slp_var, NA,               L1_var,  L1_sd),
  c(L2_Q_fixef_var,   NA,            NA,               L2_ranef_int_var, L2_var,  L2_sd),
  c((L1_P_fixef_var+L2_Q_fixef_var), L1_resid_var, L1_ranef_slp_var, L2_ranef_int_var, tot_var, tot_sd)
))
row_labels <- c("L1 Coeff","L2 Coeff", "All Coeff")
colnames(var_decomp_table) <- c("PredictorVar","L1Var","L1SlpVar","L2Var","TotVar","SD")
var_decomp_table <- cbind(row_labels,var_decomp_table)

var_decomp_table # print

write.csv(var_decomp_table,"MLMES_applied_HSB_mod_varcomp_results_m1b.csv",row.names = FALSE)


### ** compute R^2 ----
L1_Rsq_Fixed_Lev <- as.numeric(L1_P_fixef_var/L1_var)
L1_Rsq_Fixed_Tot <- as.numeric(L1_P_fixef_var/tot_var)
L2_Rsq_Fixed_Lev <- as.numeric(L2_Q_fixef_var/L2_var)
L2_Rsq_Fixed_Tot <- as.numeric(L2_Q_fixef_var/tot_var)
BothLev_Rsq_Fixed_Tot <- as.numeric((L1_P_fixef_var+L2_Q_fixef_var)/tot_var)
# L1_Rsq_Fixed_Lev
# L2_Rsq_Fixed_Lev
# L1_Rsq_Fixed_Tot
# L2_Rsq_Fixed_Tot
# BothLev_Rsq_Fixed_Tot

#### as check: compute same R^2 using r2mlm package ----
r2mlm(model, bargraph = FALSE)$R2s
R2_list <- r2mlm(model, bargraph = FALSE)$R2s
R2_tot <- R2_list[,1]
R2_w   <- R2_list[,2]
R2_b   <- R2_list[,3]
R2_vals <- as.data.frame(rbind(R2_w,R2_b,R2_tot))
R2_vals$type <- c("w","b","tot")
row.names(R2_vals) <- NULL
R2_vals <- R2_vals %>% relocate(type, .before = f1)
# R2_vals
L1_lev_R2w <- as.numeric(R2_vals[1,2])
L2_lev_R2b <- as.numeric(R2_vals[2,3])
L1_tot_R2w <- as.numeric(R2_vals[3,2])
L2_tot_R2b <- as.numeric(R2_vals[3,3])
tot_R2tot  <- as.numeric(R2_vals[3,6])
# L1_lev_R2w
# L2_lev_R2b
# L1_tot_R2w
# L2_tot_R2b
# tot_R2tot

#### optional: format, print, save R-square results from r2mlm table ----
R2_vals_table <- as.data.frame(t(R2_vals))
R2_vals_table <- R2_vals_table[-c(1), ]
colnames(R2_vals_table) <- c("L1_within","L2_between","Total")
R2_vals_table$L1_within <- round(as.numeric(R2_vals_table$L1_within),4)
R2_vals_table$L2_between <- round(as.numeric(R2_vals_table$L2_between),4)
R2_vals_table$Total <- round(as.numeric(R2_vals_table$Total),4)
R2_vals_table$Type <- c("Fixed_L1","Fixed_L2","Rand_slp","Rand_int","Fixed_all","Fixed_all_Rand_slp","All")
R2_vals_table <- R2_vals_table %>% relocate(Type, .before = L1_within)
row.names(R2_vals_table) <- NULL

R2_vals_table # print

sum(R2_vals_table$Total[1:4])
write.csv(R2_vals_table,"MLMES_applied_HSB_mod_r2mlm_R2_ESresults_m1b.csv",row.names = FALSE)

### ** create model results dataframe ----

#### summary of model results ----
summ    <- summary(model)

#### assign coef level based on get_L1L2_predictors() function ----
coef     <- names(fixef(model))
coef_lev <- ifelse(coef == "(Intercept)", 2,        # always treat intercept as L2
                   ifelse(coef %in% L1_names, 1,
                          ifelse(coef %in% L2_names, 2, NA)))
coef_info <- as.data.frame(cbind(coef,coef_lev))
coef_info$coef <- as.character(coef_info$coef)
coef_info$coef_lev <- as.numeric(coef_info$coef_lev)
coef_info$rand_slp <- ifelse(coef_info$coef %in% RE_slp_names, 1, 0)
coef_info$rand_slp <- as.numeric(coef_info$rand_slp)

#### get lme4 results ----
b       <- as.numeric(summ$coef[,1])
se      <- as.numeric(summ$coef[,2])
t       <- as.numeric(summ$coef[,4])
df_Sat  <- as.numeric(summ$coef[,3]) # Satterthwaite df is default for lme4
p_Sat   <- as.numeric(round(summ$coef[,5], 6)) # p-value based on t with lme4 df

lme4_results <- as.data.frame(cbind(b,se,t,df_Sat,p_Sat))

results <- cbind(coef_info,lme4_results)

#### compute BW df ----
N = model@devcomp$dims[["N"]]
J = as.numeric(ngrps(model, RE_cluster_name))
M = as.numeric(c(N/J))
ICC = as.numeric(c(L2_ranef_int_var/tot_var))
Pr = as.numeric(RE_slp_count)
Pf1 = nrow(L1_P_coef_names)
Q   = nrow(L2_Q_coef_names)
df_bw_L1     = as.numeric(c(N - J - Pf1             )) # only in no-random slope models
df_bw_L2     = as.numeric(c(    J -            Q - 1))
df_bw_tot    = as.numeric(c(N - J - Pf1 - Pr - Q - 1))
J
Pf1
Pr
Q
df_bw_L1
df_bw_L2
df_bw_tot

#### assign BW df ----
results$df_BW <- ifelse(
  results$rand_slp == 1,                 # L1 slopes with random slope
  ifelse(results$coef_lev == 1, df_bw_L2, df_bw_L2),  # L1 → L2 df, L2 → L2 df
  ifelse(results$coef_lev == 1, df_bw_L1, df_bw_L2)   # L1 slopes without random slope → L1 df, L2 → L2 df
)
#### assign p-values to t based on BW df ----
results$p_BW <- round(as.numeric(2 * (1 - pt(abs(results$t), df = results$df_BW))),6)

colnames(results) <- c("Predictor","level","rs","b","SE","t","df_Sat","p_Sat","df_BW","p_BW")
results

### ** compute adj_d ----

#### level-specific ----
results$adj_d_lev <- ifelse(
  results$level == 1,
  results$b / L1_sd,
  results$b / L2_sd)

#### total ----
results$adj_d_tot <- results$b/ tot_sd
results


### ** compute sr^2 ----

#### get conditional predictor variances ----
###### function conditional_variances() ----
conditional_variances <- function(data, predictors) {
  cond_vars <- setNames(numeric(length(predictors)), predictors)

  for (pred in predictors) {
    others <- setdiff(predictors, pred)
    if (length(others) == 0) {
      cond_vars[pred] <- var(data[[pred]], na.rm = TRUE)
    } else {
      fit <- lm(data[[pred]] ~ ., data = data[others])
      cond_vars[pred] <- var(resid(fit), na.rm = TRUE)
    }
  }
  cond_vars
}

##### function wrapper relying on getL1L2predictors() ----
get_conditional_variances <- function(model, data) {
  clust_var <- names(model@flist)[1]
  preds <- get_L1L2_predictors(model, clust_var)
  out <- list()

  # L1 conditional variances
  if (length(preds$L1) > 0) {
    out$L1 <- conditional_variances(data, preds$L1)
  }

  # L2 conditional variances (aggregate to cluster means first)
  if (length(preds$L2) > 0) {
    level2_data <- data %>%
      group_by(.data[[clust_var]]) %>%
      summarise(across(all_of(preds$L2), \(x) mean(x, na.rm = TRUE)), .groups = "drop")
    out$L2 <- conditional_variances(level2_data, preds$L2)
  }

  out
}

##### apply function to model and data ----
##### get_conditional_variances(model, data)
cond_variance <- get_conditional_variances(model, data)
cond_variance$L1
cond_variance$L2

##### add conditional variances to 'results' ----
results$cond_variance <- NA_real_ #initialize
for (i in seq_len(nrow(results))) {
  pred <- results$Predictor[i]
  lev  <- results$level[i]

  if (pred == "(Intercept)") {
    # Intercept always treated as L2
    results$cond_variance[i] <- NA_real_  # or set to a fixed value if you prefer
  } else if (lev == 1 && pred %in% names(cond_variance$L1)) {
    results$cond_variance[i] <- cond_variance$L1[pred]
  } else if (lev == 2 && pred %in% names(cond_variance$L2)) {
    results$cond_variance[i] <- cond_variance$L2[pred]
  }
}

#### level-specific ----
results$sr2_lev <- ifelse(
  results$level == 1,
  (results$b^2) * results$cond_variance / L1_var,
  (results$b^2) * results$cond_variance / L2_var
)

#### total ----
results$sr2_tot <- (results$b^2)*results$cond_variance / tot_var

### remove unneeded results ----
results$cond_variance <- NULL

### print results ----
results

### optional: formatting and saving results ----
format_results           <- results
format_results$b         <- round(format_results$b,2)
format_results$SE        <- round(format_results$SE,2)
format_results$t         <- round(format_results$t,2)
format_results$df_Sat    <- round(format_results$df_Sat,2)
format_results$p_Sat     <- round(format_results$p_Sat,4)
format_results$df_BW     <- round(format_results$df_BW,0)
format_results$p_BW      <- round(format_results$p_BW,4)
format_results$adj_d_lev <- round(format_results$adj_d_lev,4)
format_results$adj_d_tot <- round(format_results$adj_d_tot,4)
format_results$sr2_lev   <- round(format_results$sr2_lev,4)
format_results$sr2_tot   <- round(format_results$sr2_tot,4)

format_results$Variable <- car::recode(format_results$Predictor, "
                                         '(Intercept)' = 'Intercept';
'minority_eff_CMC' = 'Student Minority Status (Effect-coded)';
'female_eff_CMC'   = 'Student Female Status (Effect-coded)';
'ses_CMC'   = 'Student SES (CMC)';
'ses_agg_GMC'   = 'School SES (Sample Aggregate, GMC)';
'sqrt_size_GMC' = 'School Size (Sqrt Transformed, GMC)';
'sector_eff'    = 'School Private/Catholic Status (Effect-coded)';
'disclim_GMC'   = 'School Discipline Climate (GMC)';
'himinty_eff'   = 'School High % Minority Status (Effect-coded)'")
format_results <- format_results %>% relocate(Variable, .before = everything())
format_results$Predictor <- NULL
format_results$level <- NULL
format_results$rs <- NULL
names(format_results)[names(format_results) == "b"] <- "Coeff"
row.names(format_results) <- NULL

format_results # print

write.csv(format_results,"MLMES_applied_HSB_mod_coef_ESresults_m1b.csv",row.names=FALSE) #save


## 3) ** m1c random int + 3 random L1 slopes ----
### !! user specified ----
model <- hsb_m1c    ##### !! user specified
data  <- hsb_data   ##### !! user specified

### get number of random effects ----
get_random_effects <- function(model) {
  vc_list <- VarCorr(model)

  # Extract clean cluster names (remove suffixes like ".1", ".2")
  cluster_names <- gsub("\\.\\d+$", "", names(vc_list))
  split_list <- split(vc_list, cluster_names)

  total_intercept <- 0
  total_slopes <- 0
  slope_names <- c()
  cluster_var_names <- unique(cluster_names)

  for (cluster_mats in split_list) {
    all_rows <- unlist(lapply(cluster_mats, rownames))

    # Remove cluster prefix if present
    prefix <- names(cluster_mats)[1]
    all_rows <- sub(paste0("^", prefix, "\\."), "", all_rows)

    # Count intercepts
    has_intercept <- any(all_rows == "(Intercept)")
    total_intercept <- total_intercept + as.integer(has_intercept)

    # Extract slopes
    slopes <- all_rows[all_rows != "(Intercept)"]
    total_slopes <- total_slopes + length(slopes)

    # Store slope names
    slope_names <- c(slope_names, slopes)
  }

  # Remove duplicate slope names
  slope_names <- unique(slope_names)

  # Return named list
  list(
    cluster_names   = cluster_var_names,
    rand_int_count = total_intercept,
    rand_slp_count = total_slopes,
    rand_slp_names = slope_names
  )
}

# store cluster variable name
RE_cluster_name <- get_random_effects(model)$cluster_names
RE_cluster_name

# store random effects counts
RE_int_count <- get_random_effects(model)$rand_int_count
RE_slp_count <- get_random_effects(model)$rand_slp_count
num_ran_eff =  RE_int_count + RE_slp_count
RE_int_count
RE_slp_count
num_ran_eff

# store random slope predictor information as simple list
RE_slp_names <- get_random_effects(model)$rand_slp_names
RE_slp_names <- as.character(RE_slp_names)
RE_slp_names

# store random slope predictor as comma-separated quoted list
RE_slp_names_raw <- get_random_effects(model)$rand_slp_names
RE_slp_names_list <- as.character(RE_slp_names_raw)
RE_slp_names_list

# store random slope predictor as matrix (can only use this if there are any random slopes)
RE_slp_names_matrix <- as.matrix(get_random_effects(model)$rand_slp_names)
colnames(RE_slp_names_matrix) <- c("Predictor")


### get names of predictors for each level ----
get_L1L2_predictors <- function(model, cluster_var) {
  # extract the data actually used in the model
  mf <- model.frame(model)

  # get clustering variable name
  cluster_var <- names(model@flist)

  # get predictor names (exclude response and cluster_var itself)
  predictors <- setdiff(names(mf), c(all.vars(formula(model)[[2]]), cluster_var))

  # for each predictor, check if it varies within clusters
  results <- sapply(predictors, function(p) {
    by_vals <- tapply(mf[[p]], mf[[cluster_var]], function(x) length(unique(x)))
    if (all(by_vals == 1)) {
      return("L2")   # constant within each cluster
    } else {
      return("L1")   # varies within at least one cluster
    }
  })

  # return lists of names
  list(
    L2 = names(results[results == "L2"]),
    L1 = names(results[results == "L1"])
  )
}

# store predictor names as simple list
L1_names <- get_L1L2_predictors(model)$L1
L2_names <- get_L1L2_predictors(model)$L2
L1_names <- as.character(L1_names)
L2_names <- as.character(L2_names)

# store predictor names as comma-separated quoted
L1_names_raw <- get_L1L2_predictors(model)$L1
L2_names_raw <- get_L1L2_predictors(model)$L2
L1_P_coef_list <- as.character(L1_names_raw)
L2_Q_coef_list <- as.character(L2_names_raw)

# store predictor names as matrix
L1_P_coef_names <- as.matrix(get_L1L2_predictors(model)$L1)
colnames(L1_P_coef_names) <- c("Predictor")
L2_Q_coef_names <- as.matrix(get_L1L2_predictors(model)$L2)
colnames(L2_Q_coef_names) <- c("Predictor")

### compute FE variance ----

#### model coef values ----
all_coef_names <- as.data.frame(names(fixef(model)))
all_coef_vals <- as.numeric(summary(model)$coef[,1])
all_coef      <- cbind(all_coef_names,all_coef_vals)
colnames(all_coef) <- c("Predictor","Coeff")
all_coef$Predictor <- as.character(all_coef$Predictor)
L1_P_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L1_names, ])
L2_Q_coef <- as.data.frame(all_coef[all_coef$Predictor %in% L2_names, ])
L1_P_coef$Predictor <- NULL
L2_Q_coef$Predictor <- NULL
L1_P_coef <- as.matrix(L1_P_coef)
L2_Q_coef <- as.matrix(L2_Q_coef)

#### varcov of predictors ----
L1_P_fixef_cov <- cov(data[L1_P_coef_list])
L2_Q_fixef_cov <- cov(data[L2_Q_coef_list])
L1_P_fixef_cov   <- as.matrix(L1_P_fixef_cov)
L2_Q_fixef_cov   <- as.matrix(L2_Q_fixef_cov)

#### var components by level ----
L1_P_fixef_var   <- t(L1_P_coef)%*%L1_P_fixef_cov%*%L1_P_coef
L2_Q_fixef_var   <- t(L2_Q_coef)%*%L2_Q_fixef_cov%*%L2_Q_coef

### compute RE variances ----

#### create Z design matrix for random slope effects ----
#### when Pr = 0 random slopes then no Z matrix needed
Z_matrix <- data[RE_slp_names_list]
Z_matrix$Intercept <- c(rep(1,nrow(Z_matrix)))
Z_matrix <- Z_matrix <- Z_matrix %>% relocate(Intercept, .before = everything())
Sigma_matrix <- as.matrix(cov(Z_matrix))
Tau_matrix <- as.matrix(Matrix::bdiag(VarCorr(model)))
Product_Sigma_Tau <- Sigma_matrix%*%Tau_matrix
L2_ranef_int_var <- as.numeric(Tau_matrix[1,1]) # intercept variance
L1_ranef_slp_var <- sum(Product_Sigma_Tau[2:num_ran_eff,2:num_ran_eff]) #var + 2*covar, exclude intercept var
# L1_ranef_slp_var <- 0 #no random slope effects
L1_resid_var <- as.data.frame(VarCorr(model))[which(as.data.frame(VarCorr(model))$grp == 'Residual'),'vcov']
Sigma_matrix
Tau_matrix
L2_ranef_int_var
L1_ranef_slp_var

#### optional: format, print, save var comp results ----
L1_var  = as.numeric(L1_P_fixef_var + L1_ranef_slp_var + L1_resid_var)
L2_var  = as.numeric(L2_Q_fixef_var + L2_ranef_int_var)
tot_var = as.numeric(L1_var + L2_var)
tot_sd  = as.numeric(sqrt(tot_var))
L1_sd   = as.numeric(sqrt(L1_var))
L2_sd   = as.numeric(sqrt(L2_var))
var_decomp_table <- as.data.frame(rbind(
  c(L1_P_fixef_var,   L1_resid_var,  L1_ranef_slp_var, NA,               L1_var,  L1_sd),
  c(L2_Q_fixef_var,   NA,            NA,               L2_ranef_int_var, L2_var,  L2_sd),
  c((L1_P_fixef_var+L2_Q_fixef_var), L1_resid_var, L1_ranef_slp_var, L2_ranef_int_var, tot_var, tot_sd)
))
row_labels <- c("L1 Coeff","L2 Coeff", "All Coeff")
colnames(var_decomp_table) <- c("PredictorVar","L1Var","L1SlpVar","L2Var","TotVar","SD")
var_decomp_table <- cbind(row_labels,var_decomp_table)

var_decomp_table # print

write.csv(var_decomp_table,"MLMES_applied_HSB_mod_varcomp_results_m1c.csv",row.names = FALSE)


### ** compute R^2 ----
L1_Rsq_Fixed_Lev <- as.numeric(L1_P_fixef_var/L1_var)
L1_Rsq_Fixed_Tot <- as.numeric(L1_P_fixef_var/tot_var)
L2_Rsq_Fixed_Lev <- as.numeric(L2_Q_fixef_var/L2_var)
L2_Rsq_Fixed_Tot <- as.numeric(L2_Q_fixef_var/tot_var)
BothLev_Rsq_Fixed_Tot <- as.numeric((L1_P_fixef_var+L2_Q_fixef_var)/tot_var)
# L1_Rsq_Fixed_Lev
# L2_Rsq_Fixed_Lev
# L1_Rsq_Fixed_Tot
# L2_Rsq_Fixed_Tot
# BothLev_Rsq_Fixed_Tot

#### as check: compute same R^2 using r2mlm package ----
r2mlm(model, bargraph = FALSE)$R2s
R2_list <- r2mlm(model, bargraph = FALSE)$R2s
R2_tot <- R2_list[,1]
R2_w   <- R2_list[,2]
R2_b   <- R2_list[,3]
R2_vals <- as.data.frame(rbind(R2_w,R2_b,R2_tot))
R2_vals$type <- c("w","b","tot")
row.names(R2_vals) <- NULL
R2_vals <- R2_vals %>% relocate(type, .before = f1)
# R2_vals
L1_lev_R2w <- as.numeric(R2_vals[1,2])
L2_lev_R2b <- as.numeric(R2_vals[2,3])
L1_tot_R2w <- as.numeric(R2_vals[3,2])
L2_tot_R2b <- as.numeric(R2_vals[3,3])
tot_R2tot  <- as.numeric(R2_vals[3,6])
# L1_lev_R2w
# L2_lev_R2b
# L1_tot_R2w
# L2_tot_R2b
# tot_R2tot

#### optional: format, print, save R-square results from r2mlm table ----
R2_vals_table <- as.data.frame(t(R2_vals))
R2_vals_table <- R2_vals_table[-c(1), ]
colnames(R2_vals_table) <- c("L1_within","L2_between","Total")
R2_vals_table$L1_within <- round(as.numeric(R2_vals_table$L1_within),4)
R2_vals_table$L2_between <- round(as.numeric(R2_vals_table$L2_between),4)
R2_vals_table$Total <- round(as.numeric(R2_vals_table$Total),4)
R2_vals_table$Type <- c("Fixed_L1","Fixed_L2","Rand_slp","Rand_int","Fixed_all","Fixed_all_Rand_slp","All")
R2_vals_table <- R2_vals_table %>% relocate(Type, .before = L1_within)
row.names(R2_vals_table) <- NULL

R2_vals_table # print

sum(R2_vals_table$Total[1:4])
write.csv(R2_vals_table,"MLMES_applied_HSB_mod_r2mlm_R2_ESresults_m1c.csv",row.names = FALSE)

### ** create model results dataframe ----

#### summary of model results ----
summ    <- summary(model)

#### assign coef level based on get_L1L2_predictors() function ----
coef     <- names(fixef(model))
coef_lev <- ifelse(coef == "(Intercept)", 2,        # always treat intercept as L2
                   ifelse(coef %in% L1_names, 1,
                          ifelse(coef %in% L2_names, 2, NA)))
coef_info <- as.data.frame(cbind(coef,coef_lev))
coef_info$coef <- as.character(coef_info$coef)
coef_info$coef_lev <- as.numeric(coef_info$coef_lev)
coef_info$rand_slp <- ifelse(coef_info$coef %in% RE_slp_names, 1, 0)
coef_info$rand_slp <- as.numeric(coef_info$rand_slp)

#### get lme4 results ----
b       <- as.numeric(summ$coef[,1])
se      <- as.numeric(summ$coef[,2])
t       <- as.numeric(summ$coef[,4])
df_Sat  <- as.numeric(summ$coef[,3]) # Satterthwaite df is default for lme4
p_Sat   <- as.numeric(round(summ$coef[,5], 6)) # p-value based on t with lme4 df

lme4_results <- as.data.frame(cbind(b,se,t,df_Sat,p_Sat))

results <- cbind(coef_info,lme4_results)

#### compute BW df ----
N = model@devcomp$dims[["N"]]
J = as.numeric(ngrps(model, RE_cluster_name))
M = as.numeric(c(N/J))
ICC = as.numeric(c(L2_ranef_int_var/tot_var))
Pr = as.numeric(RE_slp_count)
Pf1 = nrow(L1_P_coef_names)
Q   = nrow(L2_Q_coef_names)
df_bw_L1     = as.numeric(c(N - J - Pf1             )) # only in no-random slope models
df_bw_L2     = as.numeric(c(    J -            Q - 1))
df_bw_tot    = as.numeric(c(N - J - Pf1 - Pr - Q - 1))
J
Pf1
Pr
Q
df_bw_L1
df_bw_L2
df_bw_tot

#### assign BW df ----
results$df_BW <- ifelse(
  results$rand_slp == 1,                 # L1 slopes with random slope
  ifelse(results$coef_lev == 1, df_bw_L2, df_bw_L2),  # L1 → L2 df, L2 → L2 df
  ifelse(results$coef_lev == 1, df_bw_L1, df_bw_L2)   # L1 slopes without random slope → L1 df, L2 → L2 df
)
#### assign p-values to t based on BW df ----
results$p_BW <- round(as.numeric(2 * (1 - pt(abs(results$t), df = results$df_BW))),6)

colnames(results) <- c("Predictor","level","rs","b","SE","t","df_Sat","p_Sat","df_BW","p_BW")
results

### ** compute adj_d ----

#### level-specific ----
results$adj_d_lev <- ifelse(
  results$level == 1,
  results$b / L1_sd,
  results$b / L2_sd)

#### total ----
results$adj_d_tot <- results$b/ tot_sd
results


### ** compute sr^2 ----

#### get conditional predictor variances ----
###### function conditional_variances() ----
conditional_variances <- function(data, predictors) {
  cond_vars <- setNames(numeric(length(predictors)), predictors)

  for (pred in predictors) {
    others <- setdiff(predictors, pred)
    if (length(others) == 0) {
      cond_vars[pred] <- var(data[[pred]], na.rm = TRUE)
    } else {
      fit <- lm(data[[pred]] ~ ., data = data[others])
      cond_vars[pred] <- var(resid(fit), na.rm = TRUE)
    }
  }
  cond_vars
}

##### function wrapper relying on getL1L2predictors() ----
get_conditional_variances <- function(model, data) {
  clust_var <- names(model@flist)[1]
  preds <- get_L1L2_predictors(model, clust_var)
  out <- list()

  # L1 conditional variances
  if (length(preds$L1) > 0) {
    out$L1 <- conditional_variances(data, preds$L1)
  }

  # L2 conditional variances (aggregate to cluster means first)
  if (length(preds$L2) > 0) {
    level2_data <- data %>%
      group_by(.data[[clust_var]]) %>%
      summarise(across(all_of(preds$L2), \(x) mean(x, na.rm = TRUE)), .groups = "drop")
    out$L2 <- conditional_variances(level2_data, preds$L2)
  }

  out
}

##### apply function to model and data ----
##### get_conditional_variances(model, data)
cond_variance <- get_conditional_variances(model, data)
cond_variance$L1
cond_variance$L2

##### add conditional variances to 'results' ----
results$cond_variance <- NA_real_ #initialize
for (i in seq_len(nrow(results))) {
  pred <- results$Predictor[i]
  lev  <- results$level[i]

  if (pred == "(Intercept)") {
    # Intercept always treated as L2
    results$cond_variance[i] <- NA_real_  # or set to a fixed value if you prefer
  } else if (lev == 1 && pred %in% names(cond_variance$L1)) {
    results$cond_variance[i] <- cond_variance$L1[pred]
  } else if (lev == 2 && pred %in% names(cond_variance$L2)) {
    results$cond_variance[i] <- cond_variance$L2[pred]
  }
}

#### level-specific ----
results$sr2_lev <- ifelse(
  results$level == 1,
  (results$b^2) * results$cond_variance / L1_var,
  (results$b^2) * results$cond_variance / L2_var
)

#### total ----
results$sr2_tot <- (results$b^2)*results$cond_variance / tot_var

### remove unneeded results ----
results$cond_variance <- NULL

### print results ----
results

### optional: formatting and saving results ----
format_results           <- results
format_results$b         <- round(format_results$b,2)
format_results$SE        <- round(format_results$SE,2)
format_results$t         <- round(format_results$t,2)
format_results$df_Sat    <- round(format_results$df_Sat,2)
format_results$p_Sat     <- round(format_results$p_Sat,4)
format_results$df_BW     <- round(format_results$df_BW,0)
format_results$p_BW      <- round(format_results$p_BW,4)
format_results$adj_d_lev <- round(format_results$adj_d_lev,4)
format_results$adj_d_tot <- round(format_results$adj_d_tot,4)
format_results$sr2_lev   <- round(format_results$sr2_lev,4)
format_results$sr2_tot   <- round(format_results$sr2_tot,4)

format_results$Variable <- car::recode(format_results$Predictor, "
                                         '(Intercept)' = 'Intercept';
'minority_eff_CMC' = 'Student Minority Status (Effect-coded)';
'female_eff_CMC'   = 'Student Female Status (Effect-coded)';
'ses_CMC'   = 'Student SES (CMC)';
'ses_agg_GMC'   = 'School SES (Sample Aggregate, GMC)';
'sqrt_size_GMC' = 'School Size (Sqrt Transformed, GMC)';
'sector_eff'    = 'School Private/Catholic Status (Effect-coded)';
'disclim_GMC'   = 'School Discipline Climate (GMC)';
'himinty_eff'   = 'School High % Minority Status (Effect-coded)'")
format_results <- format_results %>% relocate(Variable, .before = everything())
format_results$Predictor <- NULL
format_results$level <- NULL
format_results$rs <- NULL
names(format_results)[names(format_results) == "b"] <- "Coeff"
row.names(format_results) <- NULL

format_results # print

write.csv(format_results,"MLMES_applied_HSB_mod_coef_ESresults_m1c.csv",row.names=FALSE) #save
