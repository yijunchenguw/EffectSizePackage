#' ex1 hsb Dataset
#'
#' A dataset used for effect size test example
#'
#' @format ## hsb_data
#' A dataset used for effect size test example:
#' \describe{
#'   \item{school}{student}
#'   \item{minority}{size}
#'
#' }
"hsb_data"
