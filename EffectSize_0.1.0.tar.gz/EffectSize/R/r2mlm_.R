# r2mlm_test <- function(model) {
#   model <- hsb_m1
#   # call appropriate r2mlm helper function
#   if (typeof(model) == "list") {
#     r2mlm_nlme(model)
#   } else if (typeof(model) == "S4") {
#     r2mlm_lmer_test(model)
#   } else {
#     stop("You must input a model generated using either the lme4 or nlme package.")
#   }
#
# }
# r2mlm_lmer_test <- function(model) {
#
#   # Step 1) check if model has_intercept
#
#   if ((terms(model) %>% attr("intercept")) == 1) {
#     has_intercept = TRUE
#   } else {
#     has_intercept = FALSE
#   }
#
#   # Step 2) Pull all variable names from the formula
#   all_variables <- all.vars(formula(model))
#   cluster_variable <- all_variables[length(all_variables)] # pull cluster, we'll need it later
#
#   # Step 3a) pull and prepare data
#
#   data <- prepare_data(model, "lme4", cluster_variable)
#
#   # Step 3b) determine whether data is appropriate format. Only the cluster variable can be a factor, for now
#   # a) Pull all variables except for cluster
#
#   outcome_and_predictors <- all_variables[1:(length(all_variables) - 1)]
#
#   # b) If any of those variables is non-numeric, then throw an error
#
#   for (variable in outcome_and_predictors) {
#
#     if (!is(data[[variable]], "integer") && !is(data[[variable]], "numeric")) {
#       stop("Your data must be numeric. Only the cluster variable can be a factor.")
#     }
#
#   }
#
#   # Step 4) Fill l1 and l2 vectors
#
#   # * Step 4a) Define variables you'll be sorting
#   # take the outcome out of the predictors with [2:length(outcome_and_predictors)], then add interaction terms
#
#   # sometimes the outcome_and_predictors is only an outcome variable (for the null model). If that's the case, then
#   #     predictors is null, just call get_interaction_vars just in case
#
#   if (length(outcome_and_predictors) == 1) {
#     predictors <- get_interaction_vars(model)
#   } else {
#     predictors <- append(outcome_and_predictors[2:length(outcome_and_predictors)], get_interaction_vars(model))
#   }
#
#   # * Step 4b) Create and fill vectors
#   l1_vars <- sort_variables(data, predictors, cluster_variable)$l1_vars
#   l2_vars <- sort_variables(data, predictors, cluster_variable)$l2_vars
#
#   # Step 5) pull variable names for L1 predictors with random slopes into a variable called random_slope_vars
#
#   random_slope_vars <- get_random_slope_vars(model, has_intercept, "lme4")
#
#   # Step 6) determine value of centeredwithincluster
#
#   if (is.null(l1_vars)) {
#     centeredwithincluster <- TRUE
#   } else {
#     centeredwithincluster <- get_cwc(l1_vars, cluster_variable, data)
#   }
#
#   # Step 7) pull column numbers for _covs variables
#   # 7a) within_covs (l1 variables)
#   # for (each value in l1_vars list) {match(value, names(data))}
#
#   within <- get_covs(l1_vars, data)
#
#   # 7b) pull column numbers for between_covs (l2 variables)
#
#   between <- get_covs(l2_vars, data)
#
#   # 7c) pull column numbers for random_covs (l1 variables with random slopes)
#
#   random <- get_covs(random_slope_vars, data)
#
#   # Step 8) pull gamma values (fixed slopes)
#   # 8a) gamma_w, fixed slopes for L1 variables (from l1_vars list)
#   gammaw <- c()
#   i = 1
#   for (variable in l1_vars) {
#     gammaw[i] <- fixef(model)[variable]
#     i = i + 1
#   }
#
#   # 8b) gamma_b, intercept value if hasintercept = TRUE, and fixed slopes for L2 variables (from between list)
#   gammab <- c()
#   if (has_intercept == TRUE) {
#     gammab[1] <- fixef(model)[1]
#     i = 2
#   } else {
#     i = 1
#   }
#   for (var in l2_vars) {
#     gammab[i] <- fixef(model)[var]
#     i = i + 1
#   }
#
#   # Step 9) Tau matrix, results from VarCorr(model)
#
#   vcov <- VarCorr(model)
#   tau <- as.matrix(Matrix::bdiag(vcov))
#
#   # Step 10) sigma^2 value, Rij
#
#   sigma2 <- getME(model, "sigma")^2
#
#   # Step 11) input everything into r2MLM
#
#   r2mlm_manual(as.data.frame(data), within_covs = within, between_covs = between, random_covs = random, gamma_w = gammaw, gamma_b = gammab, Tau = tau, sigma2 = sigma2, has_intercept = has_intercept, clustermeancentered = centeredwithincluster)
#
# }
# r2mlm_manual <- function(data, within_covs, between_covs, random_covs,
#                          gamma_w, gamma_b, Tau, sigma2, has_intercept = TRUE, clustermeancentered = TRUE){
#   if(has_intercept == T){
#     if(length(gamma_b)>1) gamma <- c(1, gamma_w, gamma_b[2:length(gamma_b)])
#     if(length(gamma_b) == 1) gamma <- c(1, gamma_w)
#     if(is.null(within_covs) == T) gamma_w <- 0
#   }
#   if(has_intercept == F){
#     gamma <- c(gamma_w, gamma_b)
#     if(is.null(within_covs) == T) gamma_w <- 0
#     if(is.null(between_covs) == T) gamma_b <- 0
#   }
#   if(is.null(gamma)) gamma <- 0
#   ##compute phi
#   phi <- var(cbind(1, data[, c(within_covs)], data[, c(between_covs)]), na.rm = T)
#   if(has_intercept == F) phi <- var(cbind(data[, c(within_covs)], data[, c(between_covs)]), na.rm = T)
#   if(is.null(within_covs) == T & is.null(within_covs) == T & has_intercept == F) phi <- 0
#   phi_w <- var(data[, within_covs], na.rm = T)
#   if(is.null(within_covs) == T) phi_w <- 0
#   phi_b <- var(cbind(1, data[, between_covs]), na.rm = T)
#   if(is.null(between_covs) == T) phi_b <- 0
#   ##compute psi and kappa
#   var_randomcovs <- var(cbind(1, data[, c(random_covs)]), na.rm = T)
#   if(length(Tau)>1) psi <- matrix(c(diag(Tau)), ncol = 1)
#   if(length(Tau) == 1) psi <- Tau
#   if(length(Tau)>1) kappa <- matrix(c(Tau[lower.tri(Tau) == TRUE]), ncol = 1)
#   if(length(Tau) == 1) kappa <- 0
#   v <- matrix(c(diag(var_randomcovs)), ncol = 1)
#   r <- matrix(c(var_randomcovs[lower.tri(var_randomcovs) == TRUE]), ncol = 1)
#   if(is.null(random_covs) == TRUE){
#     v <- 0
#     r <- 0
#     m <- matrix(1, ncol = 1)
#   }
#   if(length(random_covs)>0) m <- matrix(c(colMeans(cbind(1, data[, c(random_covs)]), na.rm = T)), ncol = 1)
#   ##total variance
#   totalwithinvar <- (t(gamma_w)%*%phi_w%*%gamma_w) + (t(v)%*%psi + 2*(t(r)%*%kappa)) + sigma2
#   totalbetweenvar <- (t(gamma_b)%*%phi_b%*%gamma_b) + Tau[1]
#   totalvar <- totalwithinvar + totalbetweenvar
#   ##total decomp
#   decomp_fixed_within <- (t(gamma_w)%*%phi_w%*%gamma_w) / totalvar
#   decomp_fixed_between <- (t(gamma_b)%*%phi_b%*%gamma_b) / totalvar
#   decomp_fixed <- decomp_fixed_within + decomp_fixed_between
#   decomp_varslopes <- (t(v)%*%psi + 2*(t(r)%*%kappa)) / totalvar
#   decomp_varmeans <- (t(m)%*%Tau%*%m) / totalvar
#   ##within decomp
#   decomp_fixed_within_w <- (t(gamma_w)%*%phi_w%*%gamma_w) / totalwithinvar
#   decomp_varslopes_w <- (t(v)%*%psi + 2*(t(r)%*%kappa)) / totalwithinvar
#   ##between decomp
#   decomp_fixed_between_b <- (t(gamma_b)%*%phi_b%*%gamma_b) / totalbetweenvar
#   decomp_varmeans_b <- Tau[1] / totalbetweenvar
#   #NEW measures
#   if (clustermeancentered == TRUE){
#     R2_f <- decomp_fixed
#     R2_f1 <- decomp_fixed_within
#     R2_f2 <- decomp_fixed_between
#     R2_fv <- decomp_fixed + decomp_varslopes
#     R2_fvm <- decomp_fixed + decomp_varslopes + decomp_varmeans
#     R2_v <- decomp_varslopes
#     R2_m <- decomp_varmeans
#     R2_f_w <- decomp_fixed_within_w
#     R2_f_b <- decomp_fixed_between_b
#     R2_fv_w <- decomp_fixed_within_w + decomp_varslopes_w
#     R2_v_w <- decomp_varslopes_w
#     R2_m_b <- decomp_varmeans_b
#   }
#
#   if(clustermeancentered == TRUE){
#     R2_table <- matrix(c(R2_f1, R2_f2, R2_v, R2_m, R2_f, R2_fv, R2_fvm,
#                          R2_f_w, "NA", R2_v_w, "NA", "NA", R2_fv_w, "NA",
#                          "NA", R2_f_b, "NA", R2_m_b, "NA", "NA", "NA")
#                        , ncol = 3)
#     R2_table <- suppressWarnings(apply(R2_table, 2, as.numeric)) # make values numeric, not character
#     rownames(R2_table) <- c("f1", "f2", "v", "m", "f", "fv", "fvm")
#     colnames(R2_table) <- c("total", "within", "between")
#   }
#
#   Output <- list(noquote(R2_table))
#   names(Output) <- c("R2s")
#   return(Output)
# }
# prepare_data <- function(model, calling_function, cluster_variable, second_model = NULL) {
#
#   # Step 1a: pull dataframe associated with model
#   if (calling_function == "lme4") {
#     data <- model@frame
#   } else {
#     data <- model[["data"]]
#   }
#
#   # Step 2: add interaction terms to the dataframe
#
#   # * Step 2a) pull interaction terms into list
#   interaction_vars <- get_interaction_vars(model)
#
#   if(!is.null(second_model)) {
#     interaction_vars_2 <- get_interaction_vars(second_model)
#     interaction_vars <-  unique(append(interaction_vars, interaction_vars_2))
#   }
#
#   # * Step 2b) split interaction terms into halves, multiply halves to create new columns in dataframe
#
#   data <- add_interaction_vars_to_data(data, interaction_vars)
#
#   # Step 3: group data by cluster variable
#
#   data <- group_data(data, cluster_variable)
#
#   return(data)
#
# }
# get_covs <- function(variable_list, data) {
#
#   cov_list <- c() # create empty list to fill
#
#   i = 1
#   for (variable in variable_list) {
#     tmp <- match(variable, names(data)) # get column number
#     cov_list[i] <- tmp # add column number to list
#     i = i + 1
#   }
#
#   return(cov_list)
#
# }
# get_interaction_vars <- function(model) {
#
#   interaction_vars <- c()
#   x <- 1
#   for (term in attr(terms(model), "term.labels")) {
#
#     if (grepl(":", term) == TRUE) {
#       interaction_vars[x] <- term
#       x <- x + 1
#     }
#
#   }
#
#   return(interaction_vars)
#
# }
#
# add_interaction_vars_to_data <- function(data, interaction_vars) {
#
#   for (whole in interaction_vars) {
#
#     half1 <- str_split_fixed(whole, ":", 2)[1]
#     half2 <- str_split_fixed(whole, ":", 2)[2]
#
#     newcol <- dplyr::pull(data[half1] * data[half2])
#
#     data <- data %>%
#       dplyr::mutate(!!whole := newcol)
#
#   }
#
#   return(data)
#
# }
# group_data <- function(data, cluster_variable) {
#
#   data <- data %>%
#     dplyr::group_by(.data[[cluster_variable]])
#
#   return(data)
#
# }
# sort_variables <- function(data, predictors, cluster_variable) {
#
#   l1_vars <- c()
#   l2_vars <- c()
#
#   # * Step 4c) Sort variables into l1_vars and l2_vars
#
#   # set counters
#   l1_counter <- 1
#   l2_counter <- 1
#
#   # * Step 4d) loop through all variables in grouped dataset
#
#   for (variable in predictors) {
#
#     # calculate variance for each cluster
#     t <- data %>%
#       dplyr::select(cluster_variable, variable) %>%
#       dplyr::group_map(~ var(.))
#
#     # var returns NA if group only 1 row. Replace with 0
#     counter = 1
#
#     while (counter <= length(t)) {
#
#       if (is.na(t[[counter]])) {
#         t[[counter]] <- 0
#       }
#
#       counter <- counter + 1
#
#     }
#
#     # variable to track variance
#     variance_tracker <- 0
#
#     # add up the variance from each cluster
#     for (i in t) {
#       variance_tracker <- variance_tracker + i
#     }
#
#     # if each cluster has 0 variance, the sum of variance is 0, so it's an L2 variable
#     if (variance_tracker == 0) {
#       l2_vars[l2_counter] <- variable
#       l2_counter <- l2_counter + 1
#     } else {
#       l1_vars[l1_counter] <- variable
#       l1_counter <- l1_counter + 1
#     }
#
#   }
#
#   return(list("l1_vars" = l1_vars, "l2_vars" = l2_vars))
#
# }
# get_random_slope_vars <- function(model, has_intercept, calling_function) {
#
#   if (calling_function == "lme4") {
#     temp_cov_list <- ranef(model)[[1]]
#   } else if (calling_function == "nlme") {
#     temp_cov_list <- nlme::ranef(model)
#   }
#
#   # determine where to start pulling from the temp_cov_list, depending on whether you need to bypass the `(Intercept)` column
#   if (has_intercept == 1) {
#     running_count <- 2
#   } else {
#     running_count <- 1
#   }
#
#   random_slope_vars <- c()
#   x <- 1 # counter for indexing in random_slope_vars
#
#   # running count less than or equal to list length, so it traverses the entire list (doesn't leave last element off)
#   while (running_count <= length(temp_cov_list)) {
#     random_slope_vars[x] <- names(temp_cov_list[running_count])
#     x <- x + 1
#     running_count <- running_count + 1
#   }
#
#   return(random_slope_vars)
#
# }
# get_cwc <- function(l1_vars, cluster_variable, data) {
#
#   # Group data
#   # see "Indirection" here for explanation of this group_by formatting: https://dplyr.tidyverse.org/articles/programming.html
#   data_grouped <- data %>%
#     dplyr::group_by(.data[[cluster_variable]])
#
#   for (variable in l1_vars) {
#
#     # for each group for the given variable, sum all values
#     t <- data_grouped %>%
#       dplyr::select(cluster_variable, variable) %>%
#       dplyr::group_map(~ sum(.))
#
#     # establish temporary tracker
#     temp_tracker <- 0
#
#     # sum all of the sums
#     for (i in t) {
#       temp_tracker <- temp_tracker + i
#     }
#
#     # if the biggie sum is essentially zero (not exactly zero, because floating point), then the variable is CWC
#     if (abs(temp_tracker) < 0.0000001) {
#       centeredwithincluster <- TRUE
#     } else {
#       centeredwithincluster <- FALSE
#       break # break if even one variable is not CWC, because the r2mlm_manual function will need to center everything anyways
#     }
#   }
#
#   return(centeredwithincluster)
#
# }
